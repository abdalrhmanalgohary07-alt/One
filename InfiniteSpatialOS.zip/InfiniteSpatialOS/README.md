# INFINITE — A Spatial Android Experience

## Step 6 — corner app grid, frame-zone controls + two-finger gestures, screen shortcuts

What it renders: infinite white world (sky + fogged floor + faint grid), and a curved
3D dock of up to 9 real installed apps' icons with perspective scaling, glass platforms
and soft shadows. Landscape only, immersive fullscreen.

### Run
1. Open this folder in Android Studio (Koala or newer). Accept any Gradle/AGP upgrade prompt.
2. Connect the Samsung tablet (USB debugging on) and press Run.
3. If it crashes, send me the Logcat output (filter: "AndroidRuntime").

### Structure
- `DockLayout.kt`   pure layout math for the arc (radius, sizes, angles)
- `Shaders.kt`      GLSL ES 3.0 shaders (sky, floor, icon, platform/shadow)
- `SpatialRenderer.kt` OpenGL ES 3.0 renderer
- `SpatialGLSurfaceView.kt`, `MainActivity.kt`  host + immersive mode

### Not in Phase 1 (by design)
Touch/rotation of the dock (Phase 2), floating windows (3), workspaces (4),
launching apps (5), HOME launcher role (5).
