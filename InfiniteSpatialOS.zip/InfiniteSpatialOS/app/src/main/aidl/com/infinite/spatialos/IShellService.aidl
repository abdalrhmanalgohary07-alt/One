package com.infinite.spatialos;

import android.view.Surface;

interface IShellService {
    void destroy() = 16777114;
    int createDisplay(in Surface surface, int width, int height, int dpi) = 1;
    void releaseDisplay() = 2;
    String launchApp(int displayId, String component) = 3;
    String lastError() = 4;
    String exec(String command) = 5;
    oneway void injectTouch(int displayId, int action, float x, float y, long downTime) = 6;
    oneway void injectKey(int displayId, int action, int keyCode, int metaState) = 7;
}
