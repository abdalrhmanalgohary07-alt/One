package com.infinite.spatialos

/** Small in-memory log of app events and errors, shown from the bell button. */
object AppLog {
    class Entry(val time: Long, val isError: Boolean, val text: String)

    private val entries = ArrayList<Entry>()

    @Volatile
    var unseenErrors = 0
        private set

    @Volatile
    var onChange: (() -> Unit)? = null

    @Synchronized
    fun add(isError: Boolean, text: String) {
        entries.add(Entry(System.currentTimeMillis(), isError, text))
        if (entries.size > 150) entries.removeAt(0)
        if (isError) unseenErrors++
        onChange?.invoke()
    }

    @Synchronized
    fun snapshot(): List<Entry> = entries.toList()

    @Synchronized
    fun clear() {
        entries.clear()
        unseenErrors = 0
        onChange?.invoke()
    }

    fun markSeen() {
        unseenErrors = 0
        onChange?.invoke()
    }
}
