package com.infinite.spatialos

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

class SpatialRenderer(private val context: Context) : GLSurfaceView.Renderer {

    companion object {
        private const val FOV_Y = 48f
        private const val PITCH_DOWN_DEG = 10f
        private const val FLOOR_SIZE = 600f
        private const val FLOOR_Y = -2.0f
        private const val COLS = 4
        private const val VIS_ROWS = 4
        private const val MAX_DOCK_ICONS = 100
        private const val ICON_BITMAP_SIZE = 192
        private val FOG = floatArrayOf(0.925f, 0.949f, 0.976f)
    }

    private var program = 0
    private val uniforms = HashMap<String, Int>()
    private var vao = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val identity = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val model = FloatArray(16)

    private var horizonUv = 0.6f
    private var iconTextures: IntArray = IntArray(0)
    private var packages: List<String> = emptyList()
    @Volatile var dockVisible = true
    @Volatile private var dockT = 1f
    private var scrollRow = 0f
    private var targetRow = 0f
    private val ortho = FloatArray(16)
    private var labelTex = IntArray(5)
    @Volatile private var viewW = 1
    @Volatile private var viewH = 1
    private val mainHandler = Handler(Looper.getMainLooper())

    /** Called on the main thread when an app icon is tapped. If null, the app launches normally. */
    @Volatile
    var onAppTap: ((String) -> Unit)? = null

    val panelMgr = PanelManager()
    @Volatile private var vpCopy: FloatArray? = null
    private val startTime = SystemClock.uptimeMillis()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(FOG[0], FOG[1], FOG[2], 1f)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)

        program = buildProgram(Shaders.VERTEX, Shaders.FRAGMENT)
        uniforms.clear()
        for (name in listOf(
            "uVP", "uModel", "uMode", "uTex", "uColor", "uAlpha", "uHorizon", "uFog", "uRim"
        )) {
            uniforms[name] = GLES30.glGetUniformLocation(program, name)
        }

        panelMgr.init()

        createQuad()
        iconTextures = loadAppIconTextures()
        labelTex = intArrayOf("تحريك", "حجم", "دوران", "ميل", "عمق").map { makeLabel(it) }.toIntArray()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        viewW = width
        viewH = height
        val aspect = width.toFloat() / height.coerceAtLeast(1).toFloat()
        Matrix.perspectiveM(proj, 0, FOV_Y, aspect, 0.1f, 1000f)
        Matrix.setIdentityM(view, 0)
        Matrix.rotateM(view, 0, PITCH_DOWN_DEG, 1f, 0f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        vpCopy = vp.copyOf()

        val far = floatArrayOf(0f, 0f, -900f, 1f)
        val out = FloatArray(4)
        Matrix.multiplyMV(out, 0, vp, 0, far, 0)
        val ndcY = out[1] / out[3]
        horizonUv = ((ndcY + 1f) / 2f).coerceIn(0.05f, 0.98f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        GLES30.glUseProgram(program)
        GLES30.glBindVertexArray(vao)
        GLES30.glUniform1f(uniforms.getValue("uHorizon"), horizonUv)
        GLES30.glUniform3f(uniforms.getValue("uFog"), FOG[0], FOG[1], FOG[2])

        val t = (SystemClock.uptimeMillis() - startTime) / 1000f

        // Sky (full-screen quad in clip space)
        Matrix.setIdentityM(model, 0)
        Matrix.scaleM(model, 0, 2f, 2f, 1f)
        draw(identity, model, mode = 0)

        // Floor
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, 0f, FLOOR_Y, 0f)
        Matrix.rotateM(model, 0, -90f, 1f, 0f, 0f)
        Matrix.scaleM(model, 0, FLOOR_SIZE, FLOOR_SIZE, 1f)
        draw(vp, model, mode = 1)

        panelMgr.draw(vp)

        drawLabels()
        drawDock()
    }

    private fun drawLabels() {
        val now = SystemClock.uptimeMillis()
        val until = panelMgr.labelsUntil
        if (now >= until) return
        val sel = panelMgr.find(panelMgr.selectedId) ?: return
        if (!sel.hasFrame) return
        GLES30.glUseProgram(program)
        val a = ((until - now) / 400f).coerceIn(0f, 1f)
        for (mode in 0..4) {
            panelMgr.labelModel(sel, mode, model)
            draw(vp, model, mode = 2, tex = labelTex[mode], alpha = a)
        }
    }

    // ------------------------------------------------------------------ app wall (screen space)

    private fun totalRows(): Int = (iconTextures.size + COLS - 1) / COLS
    private fun maxRow(): Float = (totalRows() - VIS_ROWS).coerceAtLeast(0).toFloat()

    /** [left, top, right, bottom] of the app wall card, in pixels. */
    fun dockRect(): FloatArray {
        val w = viewW.toFloat()
        val h = viewH.toFloat()
        return floatArrayOf(w * 0.765f, h * 0.60f, w * 0.995f, h * 0.985f)
    }

    fun dockCell(): Float {
        val r = dockRect()
        return min((r[2] - r[0] - 24f) / COLS, (r[3] - r[1] - 24f) / VIS_ROWS)
    }

    fun dockContains(px: Float, py: Float): Boolean {
        if (dockT < 0.5f) return false
        val r = dockRect()
        return px >= r[0] && px <= r[2] && py >= r[1] && py <= r[3]
    }

    private fun drawDock() {
        val goal = if (dockVisible) 1f else 0f
        dockT += (goal - dockT) * 0.14f
        if (abs(goal - dockT) < 0.004f) dockT = goal
        scrollRow += (targetRow - scrollRow) * 0.25f
        if (abs(targetRow - scrollRow) < 0.002f) scrollRow = targetRow
        if (dockT < 0.01f) return
        val ease = dockT * dockT * (3f - 2f * dockT)

        Matrix.orthoM(ortho, 0, 0f, viewW.toFloat(), viewH.toFloat(), 0f, -1f, 1f)
        val rc = dockRect()
        val cardW = rc[2] - rc[0]
        val cardH = rc[3] - rc[1]
        val slide = (1f - ease) * (cardW + 30f)
        val cx = rc[0] + cardW / 2f + slide
        val cy = rc[1] + cardH / 2f

        // glass card
        panelMgr.drawRoundRect(ortho, cx, cy, cardW + 6f, cardH + 6f, 36f, 0.62f, 0.76f, 0.95f, 0.35f * ease)
        panelMgr.drawRoundRect(ortho, cx, cy, cardW, cardH, 32f, 1f, 1f, 1f, 0.74f * ease)
        // scrollbar
        if (maxRow() > 0f) {
            val track = cardH - 48f
            val barH = track * VIS_ROWS / totalRows()
            val barY = rc[1] + 24f + (track - barH) * (scrollRow / maxRow())
            panelMgr.drawRoundRect(ortho, rc[2] - 9f + slide, barY + barH / 2f, 4f, barH, 2f, 0.4f, 0.5f, 0.65f, 0.5f * ease)
        }

        GLES30.glUseProgram(program)
        val cell = dockCell()
        val offX = rc[0] + (cardW - cell * COLS) / 2f
        val offY = rc[1] + (cardH - cell * VIS_ROWS) / 2f
        val sz = cell * 0.74f

        GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
        GLES30.glScissor(
            (rc[0] + slide + 4f).toInt(),
            (viewH - rc[3] + 4f).toInt(),
            (cardW - 8f).toInt(),
            (cardH - 8f).toInt()
        )
        val firstRow = floor(scrollRow).toInt().coerceAtLeast(0)
        for (row in firstRow..(firstRow + VIS_ROWS + 1)) {
            for (col in 0 until COLS) {
                val idx = row * COLS + col
                if (idx >= iconTextures.size) break
                val ix = offX + (col + 0.5f) * cell + slide
                val iy = offY + (row - scrollRow + 0.5f) * cell

                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, ix, iy + sz * 0.07f, 0f)
                Matrix.scaleM(model, 0, sz * 1.35f, sz * 1.35f, 1f)
                draw(ortho, model, mode = 3, r = 0.2f, g = 0.3f, b = 0.45f, a = 0.10f * ease, rim = 0f)

                Matrix.setIdentityM(model, 0)
                Matrix.translateM(model, 0, ix, iy, 0f)
                Matrix.scaleM(model, 0, sz, -sz, 1f)
                draw(ortho, model, mode = 2, tex = iconTextures[idx], alpha = ease)
            }
        }
        GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
    }

    /** GL thread: scroll the wall by [rows] rows (positive = further down the list). */
    fun scrollBy(rows: Float) {
        targetRow = (targetRow + rows).coerceIn(0f, maxRow())
        // follow the finger directly while dragging
        scrollRow = (scrollRow + rows).coerceIn(0f, maxRow())
    }

    fun settle() {
        targetRow = targetRow.roundToInt().toFloat().coerceIn(0f, maxRow())
    }

    private fun iconAt(px: Float, py: Float): Int {
        val rc = dockRect()
        if (px < rc[0] || px > rc[2] || py < rc[1] || py > rc[3]) return -1
        val cell = dockCell()
        val offX = rc[0] + ((rc[2] - rc[0]) - cell * COLS) / 2f
        val offY = rc[1] + ((rc[3] - rc[1]) - cell * VIS_ROWS) / 2f
        val colF = (px - offX) / cell
        val rowF = (py - offY) / cell + scrollRow
        val col = floor(colF).toInt()
        val row = floor(rowF).toInt()
        if (col !in 0 until COLS || row < 0) return -1
        if (abs(colF - col - 0.5f) > 0.45f || abs(rowF - row - 0.5f) > 0.45f) return -1
        val idx = row * COLS + col
        return if (idx < iconTextures.size) idx else -1
    }

    fun handleTap(px: Float, py: Float) {
        if (dockT < 0.9f) return
        val idx = iconAt(px, py)
        if (idx >= 0) launch(idx)
    }

    /** GL thread. Creates a new panel and hands back its id and the Surface to render into. */
    fun createPanel(w: Int, h: Int, onReady: (Int, Surface) -> Unit) {
        val p = panelMgr.create(w, h)
        onReady(p.id, p.surface!!)
    }

    /** GL thread. */
    fun removePanel(id: Int) = panelMgr.remove(id)

    /** UI thread: which panel/part is under this screen point. */
    fun hitPanel(sx: Float, sy: Float): PanelManager.Hit? {
        val v = vpCopy ?: return null
        return panelMgr.hitTest(v, sx, sy, viewW, viewH)
    }

    fun panelUv(p: PanelManager.Panel, sx: Float, sy: Float): FloatArray? {
        val v = vpCopy ?: return null
        return panelMgr.uvOn(p, v, sx, sy, viewW, viewH)
    }

    fun dragPanel(p: PanelManager.Panel, zone: Int, dx: Float, dy: Float) =
        panelMgr.drag(p, zone, dx, dy, viewH)

    private fun launch(index: Int) {
        val pkg = packages.getOrNull(index) ?: return
        val cb = onAppTap
        if (cb != null) {
            mainHandler.post { cb(pkg) }
            return
        }
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        mainHandler.post {
            try {
                context.startActivity(intent)
            } catch (_: Throwable) {
            }
        }
    }

    private fun isUsable(ai: ApplicationInfo): Boolean {
        if (ai.sourceDir.isNullOrEmpty()) return false
        try {
            val f = ApplicationInfo::class.java.getField("isArchived")
            if (f.getBoolean(ai)) return false
        } catch (_: Throwable) {
        }
        return true
    }

    private fun draw(
        vpMatrix: FloatArray,
        modelMatrix: FloatArray,
        mode: Int,
        r: Float = 0f, g: Float = 0f, b: Float = 0f, a: Float = 1f,
        rim: Float = 0f,
        tex: Int = 0,
        alpha: Float = 1f
    ) {
        GLES30.glUniformMatrix4fv(uniforms.getValue("uVP"), 1, false, vpMatrix, 0)
        GLES30.glUniformMatrix4fv(uniforms.getValue("uModel"), 1, false, modelMatrix, 0)
        GLES30.glUniform1i(uniforms.getValue("uMode"), mode)
        GLES30.glUniform4f(uniforms.getValue("uColor"), r, g, b, a)
        GLES30.glUniform1f(uniforms.getValue("uAlpha"), alpha)
        GLES30.glUniform1f(uniforms.getValue("uRim"), rim)
        if (tex != 0) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
            GLES30.glUniform1i(uniforms.getValue("uTex"), 0)
        }
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun createQuad() {
        // x, y, u, v  (v is flipped so bitmaps are not upside down)
        val data = floatArrayOf(
            -0.5f, -0.5f, 0f, 1f,
            0.5f, -0.5f, 1f, 1f,
            -0.5f, 0.5f, 0f, 0f,
            0.5f, 0.5f, 1f, 0f
        )
        val buffer = ByteBuffer.allocateDirect(data.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        buffer.put(data).position(0)

        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        vao = ids[0]
        GLES30.glBindVertexArray(vao)

        val vbo = IntArray(1)
        GLES30.glGenBuffers(1, vbo, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.size * 4, buffer, GLES30.GL_STATIC_DRAW)

        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 16, 8)
    }

    /** Real installed apps' icons (first 9 by name). Tapping them comes in Phase 2/5. */
    private fun loadAppIconTextures(): IntArray {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        val all = infos
            .filter { it.activityInfo.packageName != context.packageName }
            .filter { isUsable(it.activityInfo.applicationInfo) }
            .distinctBy { it.activityInfo.packageName }
        val installed = all.filter {
            val dir = it.activityInfo.applicationInfo.sourceDir
            dir != null && java.io.File(dir).exists()
        }
        val chosen = (if (installed.size * 2 >= all.size) installed else all)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .take(MAX_DOCK_ICONS)

        packages = chosen.map { it.activityInfo.packageName }
        val ids = IntArray(chosen.size)
        for ((i, info) in chosen.withIndex()) {
            val bitmap = Bitmap.createBitmap(
                ICON_BITMAP_SIZE, ICON_BITMAP_SIZE, Bitmap.Config.ARGB_8888
            )
            val drawable = info.loadIcon(pm)
            drawable.setBounds(0, 0, ICON_BITMAP_SIZE, ICON_BITMAP_SIZE)
            drawable.draw(Canvas(bitmap))
            ids[i] = uploadTexture(bitmap)
            bitmap.recycle()
        }
        return ids
    }

    private fun makeLabel(text: String): Int {
        val bmp = Bitmap.createBitmap(256, 96, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.parseColor("#3B82F6"))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        p.textSize = 46f
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        c.drawText(text, 128f, 48f - (p.descent() + p.ascent()) / 2f, p)
        val id = uploadTexture(bmp)
        bmp.recycle()
        return id
    }

    private fun uploadTexture(bitmap: Bitmap): Int {
        val id = IntArray(1)
        GLES30.glGenTextures(1, id, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id[0])
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        return id[0]
    }

    private fun buildProgram(vertexSrc: String, fragmentSrc: String): Int {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertexSrc)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragmentSrc)
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        val status = IntArray(1)
        GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(prog)
            GLES30.glDeleteProgram(prog)
            throw RuntimeException("Program link failed: $log")
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(shader)
            GLES30.glDeleteShader(shader)
            throw RuntimeException("Shader compile failed: $log")
        }
        return shader
    }
}
