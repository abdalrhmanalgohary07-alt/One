package com.infinite.spatialos

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

class SpatialRenderer(private val context: Context) : GLSurfaceView.Renderer {

    companion object {
        private const val FOV_Y = 48f
        private const val PITCH_DOWN_DEG = 10f
        private const val FLOOR_SIZE = 600f
        private const val MAX_DOCK_ICONS = 60
        private const val ICON_BITMAP_SIZE = 256
        private val FOG = floatArrayOf(0.925f, 0.949f, 0.976f)
    }

    private var program = 0
    private val uniforms = HashMap<String, Int>()
    private var vao = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val identity = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val model = FloatArray(16)

    private var horizonUv = 0.6f
    private var iconTextures: IntArray = IntArray(0)
    private var slots: List<DockLayout.Slot> = emptyList()
    private var packages: List<String> = emptyList()
    private var targetCenter = 0f
    private var center = 0f
    private var viewW = 1
    private var viewH = 1
    private val mainHandler = Handler(Looper.getMainLooper())
    private val startTime = SystemClock.uptimeMillis()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(FOG[0], FOG[1], FOG[2], 1f)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)

        program = buildProgram(Shaders.VERTEX, Shaders.FRAGMENT)
        uniforms.clear()
        for (name in listOf(
            "uVP", "uModel", "uMode", "uTex", "uColor", "uAlpha", "uHorizon", "uFog", "uRim"
        )) {
            uniforms[name] = GLES30.glGetUniformLocation(program, name)
        }

        createQuad()
        iconTextures = loadAppIconTextures()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        viewW = width
        viewH = height
        val aspect = width.toFloat() / height.coerceAtLeast(1).toFloat()
        Matrix.perspectiveM(proj, 0, FOV_Y, aspect, 0.1f, 1000f)
        Matrix.setIdentityM(view, 0)
        Matrix.rotateM(view, 0, PITCH_DOWN_DEG, 1f, 0f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        val far = floatArrayOf(0f, 0f, -900f, 1f)
        val out = FloatArray(4)
        Matrix.multiplyMV(out, 0, vp, 0, far, 0)
        val ndcY = out[1] / out[3]
        horizonUv = ((ndcY + 1f) / 2f).coerceIn(0.05f, 0.98f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        GLES30.glUseProgram(program)
        GLES30.glBindVertexArray(vao)
        GLES30.glUniform1f(uniforms.getValue("uHorizon"), horizonUv)
        GLES30.glUniform3f(uniforms.getValue("uFog"), FOG[0], FOG[1], FOG[2])

        val t = (SystemClock.uptimeMillis() - startTime) / 1000f

        // Sky (full-screen quad in clip space)
        Matrix.setIdentityM(model, 0)
        Matrix.scaleM(model, 0, 2f, 2f, 1f)
        draw(identity, model, mode = 0)

        // Floor
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, 0f, DockLayout.FLOOR_Y, 0f)
        Matrix.rotateM(model, 0, -90f, 1f, 0f, 0f)
        Matrix.scaleM(model, 0, FLOOR_SIZE, FLOOR_SIZE, 1f)
        draw(vp, model, mode = 1)

        // Dock
        center += (targetCenter - center) * 0.18f
        slots = DockLayout.compute(iconTextures.size, center)
        val ordered = slots.sortedByDescending { abs(it.index - center) }
        for (s in ordered) {
            val i = s.index
            val bob = 0.012f * sin(t * 1.3f + i * 0.7f)

            // soft floor shadow
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, s.x, DockLayout.FLOOR_Y + 0.005f, s.z)
            Matrix.rotateM(model, 0, s.yawDeg, 0f, 1f, 0f)
            Matrix.rotateM(model, 0, -90f, 1f, 0f, 0f)
            Matrix.scaleM(model, 0, s.size * 2.4f, s.size * 1.5f, 1f)
            draw(vp, model, mode = 3, r = 0.25f, g = 0.35f, b = 0.5f, a = 0.10f, rim = 0f)

            // glass platform under the icon
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, s.x, s.y - s.size * 0.58f, s.z)
            Matrix.rotateM(model, 0, s.yawDeg, 0f, 1f, 0f)
            Matrix.rotateM(model, 0, -90f, 1f, 0f, 0f)
            Matrix.scaleM(model, 0, s.size * 1.25f, s.size * 0.7f, 1f)
            draw(vp, model, mode = 3, r = 0.80f, g = 0.89f, b = 0.98f, a = 0.9f, rim = 1f)

            // icon
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, s.x, s.y + bob, s.z)
            Matrix.rotateM(model, 0, s.yawDeg, 0f, 1f, 0f)
            Matrix.scaleM(model, 0, s.size, s.size, 1f)
            draw(vp, model, mode = 2, tex = iconTextures[i])
        }
    }

    fun scrollBy(deltaIcons: Float) {
        val max = (iconTextures.size - 1).coerceAtLeast(0).toFloat()
        targetCenter = (targetCenter + deltaIcons).coerceIn(0f, max)
    }

    fun settle() {
        targetCenter = targetCenter.roundToInt().toFloat()
    }

    private fun project(x: Float, y: Float, z: Float): FloatArray? {
        val inp = floatArrayOf(x, y, z, 1f)
        val out = FloatArray(4)
        Matrix.multiplyMV(out, 0, vp, 0, inp, 0)
        if (out[3] <= 0f) return null
        val nx = out[0] / out[3]
        val ny = out[1] / out[3]
        return floatArrayOf((nx + 1f) / 2f * viewW, (1f - ny) / 2f * viewH)
    }

    fun handleTap(px: Float, py: Float) {
        var best = -1
        var bestDist = Float.MAX_VALUE
        for (s in slots) {
            val c = project(s.x, s.y, s.z) ?: continue
            val top = project(s.x, s.y + s.size / 2f, s.z) ?: continue
            val radius = abs(top[1] - c[1]) * 1.25f
            val dx = px - c[0]
            val dy = py - c[1]
            val d = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            if (d <= radius && d < bestDist) {
                bestDist = d
                best = s.index
            }
        }
        if (best < 0) return
        if (best == targetCenter.roundToInt()) {
            launch(best)
        } else {
            targetCenter = best.toFloat()
        }
    }

    private fun launch(index: Int) {
        val pkg = packages.getOrNull(index) ?: return
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        mainHandler.post {
            try {
                context.startActivity(intent)
            } catch (_: Throwable) {
            }
        }
    }

    private fun isUsable(ai: ApplicationInfo): Boolean {
        if (ai.sourceDir.isNullOrEmpty()) return false
        try {
            val f = ApplicationInfo::class.java.getField("isArchived")
            if (f.getBoolean(ai)) return false
        } catch (_: Throwable) {
        }
        return true
    }

    private fun draw(
        vpMatrix: FloatArray,
        modelMatrix: FloatArray,
        mode: Int,
        r: Float = 0f, g: Float = 0f, b: Float = 0f, a: Float = 1f,
        rim: Float = 0f,
        tex: Int = 0
    ) {
        GLES30.glUniformMatrix4fv(uniforms.getValue("uVP"), 1, false, vpMatrix, 0)
        GLES30.glUniformMatrix4fv(uniforms.getValue("uModel"), 1, false, modelMatrix, 0)
        GLES30.glUniform1i(uniforms.getValue("uMode"), mode)
        GLES30.glUniform4f(uniforms.getValue("uColor"), r, g, b, a)
        GLES30.glUniform1f(uniforms.getValue("uAlpha"), 1f)
        GLES30.glUniform1f(uniforms.getValue("uRim"), rim)
        if (tex != 0) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
            GLES30.glUniform1i(uniforms.getValue("uTex"), 0)
        }
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun createQuad() {
        // x, y, u, v  (v is flipped so bitmaps are not upside down)
        val data = floatArrayOf(
            -0.5f, -0.5f, 0f, 1f,
            0.5f, -0.5f, 1f, 1f,
            -0.5f, 0.5f, 0f, 0f,
            0.5f, 0.5f, 1f, 0f
        )
        val buffer = ByteBuffer.allocateDirect(data.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        buffer.put(data).position(0)

        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        vao = ids[0]
        GLES30.glBindVertexArray(vao)

        val vbo = IntArray(1)
        GLES30.glGenBuffers(1, vbo, 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.size * 4, buffer, GLES30.GL_STATIC_DRAW)

        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 16, 8)
    }

    /** Real installed apps' icons (first 9 by name). Tapping them comes in Phase 2/5. */
    private fun loadAppIconTextures(): IntArray {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        val chosen = infos
            .filter { it.activityInfo.packageName != context.packageName }
            .filter { isUsable(it.activityInfo.applicationInfo) }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .take(MAX_DOCK_ICONS)

        packages = chosen.map { it.activityInfo.packageName }
        val ids = IntArray(chosen.size)
        for ((i, info) in chosen.withIndex()) {
            val bitmap = Bitmap.createBitmap(
                ICON_BITMAP_SIZE, ICON_BITMAP_SIZE, Bitmap.Config.ARGB_8888
            )
            val drawable = info.loadIcon(pm)
            drawable.setBounds(0, 0, ICON_BITMAP_SIZE, ICON_BITMAP_SIZE)
            drawable.draw(Canvas(bitmap))
            ids[i] = uploadTexture(bitmap)
            bitmap.recycle()
        }
        return ids
    }

    private fun uploadTexture(bitmap: Bitmap): Int {
        val id = IntArray(1)
        GLES30.glGenTextures(1, id, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id[0])
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        return id[0]
    }

    private fun buildProgram(vertexSrc: String, fragmentSrc: String): Int {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertexSrc)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragmentSrc)
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        val status = IntArray(1)
        GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(prog)
            GLES30.glDeleteProgram(prog)
            throw RuntimeException("Program link failed: $log")
        }
        return prog
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(shader)
            GLES30.glDeleteShader(shader)
            throw RuntimeException("Shader compile failed: $log")
        }
        return shader
    }
}
