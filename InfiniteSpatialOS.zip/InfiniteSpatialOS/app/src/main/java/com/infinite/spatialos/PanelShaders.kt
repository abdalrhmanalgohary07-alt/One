package com.infinite.spatialos

object PanelShaders {
    const val VERTEX = """#version 300 es
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUV;
uniform mat4 uVP;
uniform mat4 uModel;
out vec2 vUV;
void main() {
    vUV = aUV;
    gl_Position = uVP * uModel * vec4(aPos, 0.0, 1.0);
}
"""

    const val FRAGMENT = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision mediump float;
in vec2 vUV;
uniform samplerExternalOES uTex;
uniform mat4 uSTMatrix;
uniform vec4 uSolid;
uniform vec2 uSize;
uniform float uRadius;
out vec4 outColor;

float roundMask() {
    vec2 p = (vUV - 0.5) * uSize;
    vec2 q = abs(p) - (uSize * 0.5 - vec2(uRadius));
    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;
    float aa = max(fwidth(d), 0.0005);
    return 1.0 - smoothstep(-aa, aa, d);
}

void main() {
    float m = roundMask();
    if (uSolid.a > 0.0) {
        outColor = vec4(uSolid.rgb, uSolid.a * m);
        return;
    }
    vec4 c = uSTMatrix * vec4(vUV.x, 1.0 - vUV.y, 0.0, 1.0);
    outColor = vec4(texture(uTex, c.xy).rgb, m);
}
"""
}
