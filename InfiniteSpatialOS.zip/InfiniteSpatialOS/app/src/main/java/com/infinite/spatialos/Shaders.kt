package com.infinite.spatialos

object Shaders {

    const val VERTEX = """#version 300 es
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aUV;
uniform mat4 uVP;
uniform mat4 uModel;
out vec2 vUV;
out vec3 vWorld;
void main() {
    vUV = aUV;
    vec4 w = uModel * vec4(aPos, 0.0, 1.0);
    vWorld = w.xyz;
    gl_Position = uVP * w;
}
"""

    // Modes: 0 = sky, 1 = floor, 2 = app icon, 3 = soft shadow / glass platform
    const val FRAGMENT = """#version 300 es
precision highp float;
in vec2 vUV;
in vec3 vWorld;
uniform int uMode;
uniform sampler2D uTex;
uniform vec4 uColor;
uniform float uAlpha;
uniform float uHorizon;
uniform vec3 uFog;
uniform float uRim;
out vec4 fragColor;

void main() {
    if (uMode == 0) {
        float vy = 1.0 - vUV.y;
        float t = clamp((1.0 - vy) / max(1.0 - uHorizon, 0.001), 0.0, 1.0);
        vec3 col = mix(vec3(1.0), uFog, pow(t, 1.4));
        fragColor = vec4(col, 1.0);
    } else if (uMode == 1) {
        float d = length(vWorld.xz);
        float fog = smoothstep(6.0, 90.0, d);
        vec3 base = mix(vec3(0.985, 0.99, 1.0), vec3(0.94, 0.958, 0.98), smoothstep(0.0, 40.0, d));
        vec2 coord = vWorld.xz * 0.5;
        vec2 grid = abs(fract(coord - 0.5) - 0.5) / fwidth(coord);
        float line = 1.0 - min(min(grid.x, grid.y), 1.0);
        base -= vec3(0.03, 0.02, 0.01) * line;
        fragColor = vec4(mix(base, uFog, fog), 1.0);
    } else if (uMode == 2) {
        vec2 p = vUV - 0.5;
        float r = 0.22;
        vec2 q = abs(p) - (vec2(0.5) - r);
        float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
        float aa = max(fwidth(d), 0.0005);
        float mask = 1.0 - smoothstep(-aa, aa, d);
        vec4 t = texture(uTex, vUV);
        vec3 col = mix(vec3(1.0), t.rgb, t.a);
        float edge = smoothstep(-0.035, 0.0, d);
        col = mix(col, vec3(0.78, 0.87, 0.97), edge * 0.35);
        col += 0.04 * (0.5 - vUV.y);
        fragColor = vec4(col, mask * uAlpha);
    } else {
        vec2 c = (vUV - 0.5) * 2.0;
        float r = length(c);
        float a;
        vec3 col = uColor.rgb;
        if (uRim > 0.5) {
            float rim = smoothstep(0.78, 0.9, r) * (1.0 - smoothstep(0.9, 1.0, r));
            a = 0.55 * (1.0 - smoothstep(0.85, 1.0, r)) + 0.6 * rim;
            col = mix(col, vec3(0.62, 0.77, 0.93), rim);
        } else {
            a = 1.0 - smoothstep(0.0, 1.0, r);
        }
        fragColor = vec4(col, a * uColor.a);
    }
}
"""
}
