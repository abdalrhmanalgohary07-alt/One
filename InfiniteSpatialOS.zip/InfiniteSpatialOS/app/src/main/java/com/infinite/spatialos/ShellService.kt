package com.infinite.spatialos

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import org.lsposed.hiddenapibypass.HiddenApiBypass
import kotlin.system.exitProcess

/**
 * Runs in a separate process with shell (adb) privileges, started by Shizuku.
 * Creates a virtual display that renders into our Surface and launches apps on it.
 */
class ShellService : IShellService.Stub() {

    private val displays = HashMap<Int, VirtualDisplay>()
    private var error: String = ""
    private var baseCtx: Context? = null
    private val handler: Handler

    init {
        try {
            HiddenApiBypass.addHiddenApiExemptions("")
        } catch (_: Throwable) {
        }
        val ht = HandlerThread("infinite-vd")
        ht.start()
        handler = Handler(ht.looper)
        baseCtx = bootstrapContext()
    }

    private fun describe(t: Throwable): String {
        val c = t.cause
        return t.javaClass.simpleName + ": " + t.message +
            (if (c != null) " <- " + c.javaClass.simpleName + ": " + c.message else "")
    }

    private fun bootstrapContext(): Context? {
        try {
            val atClass = Class.forName("android.app.ActivityThread")
            val existing = atClass.getMethod("currentActivityThread").invoke(null)
            val at: Any
            if (existing != null) {
                at = existing
            } else {
                try {
                    Looper.prepareMainLooper()
                } catch (_: Throwable) {
                }
                val ctor = atClass.getDeclaredConstructor()
                ctor.isAccessible = true
                at = ctor.newInstance()
                val f1 = atClass.getDeclaredField("sCurrentActivityThread")
                f1.isAccessible = true
                f1.set(null, at)
                val f2 = atClass.getDeclaredField("mSystemThread")
                f2.isAccessible = true
                f2.setBoolean(at, true)
            }
            return atClass.getDeclaredMethod("getSystemContext").invoke(at) as Context
        } catch (t: Throwable) {
            error = "bootstrap: " + describe(t)
            return null
        }
    }

    private fun displayManager(): DisplayManager {
        val fake = FakeContext(baseCtx)
        val ctor = DisplayManager::class.java.getDeclaredConstructor(Context::class.java)
        ctor.isAccessible = true
        return ctor.newInstance(fake)
    }

    override fun destroy() {
        for (v in displays.values) {
            try {
                v.release()
            } catch (_: Throwable) {
            }
        }
        displays.clear()
        exitProcess(0)
    }

    override fun createDisplay(surface: Surface, width: Int, height: Int, dpi: Int): Int {
        try {
            // PUBLIC | PRESENTATION | OWN_CONTENT_ONLY | SUPPORTS_TOUCH | ROTATES_WITH_CONTENT |
            // DESTROY_CONTENT_ON_REMOVAL
            var flags = 1 or 2 or 8 or (1 shl 6) or (1 shl 7) or (1 shl 8)
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                // TRUSTED | OWN_DISPLAY_GROUP | ALWAYS_UNLOCKED | TOUCH_FEEDBACK_DISABLED
                flags = flags or (1 shl 10) or (1 shl 11) or (1 shl 12) or (1 shl 13)
            }
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                // OWN_FOCUS | DEVICE_DISPLAY_GROUP
                flags = flags or (1 shl 14) or (1 shl 15)
            }
            val dm = displayManager()
            val display = dm.createVirtualDisplay(
                "InfinitePanel", width, height, dpi, surface, flags, null, handler
            )
            if (display == null) {
                error = "createVirtualDisplay returned null"
                return -1
            }
            val id = display.display.displayId
            displays[id] = display
            return id
        } catch (t: Throwable) {
            error = "createDisplay: " + describe(t)
            return -1
        }
    }

    override fun releaseDisplay(displayId: Int) {
        try {
            displays.remove(displayId)?.release()
        } catch (_: Throwable) {
        }
    }

    override fun launchApp(displayId: Int, component: String): String {
        return exec("am start --display $displayId -n $component")
    }

    override fun lastError(): String = error

    private var inputTarget: Any? = null
    private var injectMethod: java.lang.reflect.Method? = null

    private fun ensureInput() {
        if (inputTarget != null && injectMethod != null) return
        try {
            val cls = Class.forName("android.hardware.input.InputManager")
            val target = cls.getMethod("getInstance").invoke(null)
            val m = cls.getMethod(
                "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
            )
            inputTarget = target
            injectMethod = m
            return
        } catch (t: Throwable) {
            error = "input(client): " + describe(t)
        }
        val sm = Class.forName("android.os.ServiceManager")
        val binder = sm.getMethod("getService", String::class.java).invoke(null, "input")
            as android.os.IBinder
        val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
        val target = stub.getMethod("asInterface", android.os.IBinder::class.java)
            .invoke(null, binder)!!
        inputTarget = target
        injectMethod = target.javaClass.getMethod(
            "injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType
        )
    }

    private fun inject(ev: InputEvent, displayId: Int) {
        ensureInput()
        InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
            .invoke(ev, displayId)
        injectMethod!!.invoke(inputTarget, ev, 0)
    }

    override fun injectTouch(displayId: Int, action: Int, x: Float, y: Float, downTime: Long) {
        try {
            val now = SystemClock.uptimeMillis()
            val pressure = if (action == MotionEvent.ACTION_UP) 0f else 1f
            val ev = MotionEvent.obtain(downTime, now, action, x, y, pressure, 1f, 0, 1f, 1f, 0, 0)
            ev.source = InputDevice.SOURCE_TOUCHSCREEN
            inject(ev, displayId)
            ev.recycle()
        } catch (t: Throwable) {
            error = "touch: " + describe(t)
        }
    }

    override fun injectKey(displayId: Int, action: Int, keyCode: Int, metaState: Int) {
        try {
            val now = SystemClock.uptimeMillis()
            val ev = KeyEvent(
                now, now, action, keyCode, 0, metaState, -1, 0, 0, InputDevice.SOURCE_KEYBOARD
            )
            inject(ev, displayId)
        } catch (t: Throwable) {
            error = "key: " + describe(t)
        }
    }

    override fun exec(command: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            (out + err).trim()
        } catch (t: Throwable) {
            "exec: " + describe(t)
        }
    }
}
