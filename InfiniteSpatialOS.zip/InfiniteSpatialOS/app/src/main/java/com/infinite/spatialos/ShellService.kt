package com.infinite.spatialos

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.Surface
import org.lsposed.hiddenapibypass.HiddenApiBypass
import kotlin.system.exitProcess

/**
 * Runs in a separate process with shell (adb) privileges, started by Shizuku.
 * Creates a virtual display that renders into our Surface and launches apps on it.
 */
class ShellService : IShellService.Stub() {

    private var vd: VirtualDisplay? = null
    private var error: String = ""
    private var baseCtx: Context? = null
    private val handler: Handler

    init {
        try {
            HiddenApiBypass.addHiddenApiExemptions("")
        } catch (_: Throwable) {
        }
        val ht = HandlerThread("infinite-vd")
        ht.start()
        handler = Handler(ht.looper)
        baseCtx = bootstrapContext()
    }

    private fun describe(t: Throwable): String {
        val c = t.cause
        return t.javaClass.simpleName + ": " + t.message +
            (if (c != null) " <- " + c.javaClass.simpleName + ": " + c.message else "")
    }

    private fun bootstrapContext(): Context? {
        try {
            val atClass = Class.forName("android.app.ActivityThread")
            val existing = atClass.getMethod("currentActivityThread").invoke(null)
            val at: Any
            if (existing != null) {
                at = existing
            } else {
                try {
                    Looper.prepareMainLooper()
                } catch (_: Throwable) {
                }
                val ctor = atClass.getDeclaredConstructor()
                ctor.isAccessible = true
                at = ctor.newInstance()
                val f1 = atClass.getDeclaredField("sCurrentActivityThread")
                f1.isAccessible = true
                f1.set(null, at)
                val f2 = atClass.getDeclaredField("mSystemThread")
                f2.isAccessible = true
                f2.setBoolean(at, true)
            }
            return atClass.getDeclaredMethod("getSystemContext").invoke(at) as Context
        } catch (t: Throwable) {
            error = "bootstrap: " + describe(t)
            return null
        }
    }

    private fun displayManager(): DisplayManager {
        val fake = FakeContext(baseCtx)
        val ctor = DisplayManager::class.java.getDeclaredConstructor(Context::class.java)
        ctor.isAccessible = true
        return ctor.newInstance(fake)
    }

    override fun destroy() {
        releaseDisplay()
        exitProcess(0)
    }

    override fun createDisplay(surface: Surface, width: Int, height: Int, dpi: Int): Int {
        try {
            releaseDisplay()
            // PUBLIC | PRESENTATION | OWN_CONTENT_ONLY | SUPPORTS_TOUCH | ROTATES_WITH_CONTENT |
            // DESTROY_CONTENT_ON_REMOVAL
            var flags = 1 or 2 or 8 or (1 shl 6) or (1 shl 7) or (1 shl 8)
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                // TRUSTED | OWN_DISPLAY_GROUP | ALWAYS_UNLOCKED | TOUCH_FEEDBACK_DISABLED
                flags = flags or (1 shl 10) or (1 shl 11) or (1 shl 12) or (1 shl 13)
            }
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                // OWN_FOCUS | DEVICE_DISPLAY_GROUP
                flags = flags or (1 shl 14) or (1 shl 15)
            }
            val dm = displayManager()
            val display = dm.createVirtualDisplay(
                "InfinitePanel", width, height, dpi, surface, flags, null, handler
            )
            vd = display
            if (display == null) {
                error = "createVirtualDisplay returned null"
                return -1
            }
            return display.display.displayId
        } catch (t: Throwable) {
            error = "createDisplay: " + describe(t)
            return -1
        }
    }

    override fun releaseDisplay() {
        try {
            vd?.release()
        } catch (_: Throwable) {
        }
        vd = null
    }

    override fun launchApp(displayId: Int, component: String): String {
        return exec("am start --display $displayId -n $component")
    }

    override fun lastError(): String = error

    override fun exec(command: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            (out + err).trim()
        } catch (t: Throwable) {
            "exec: " + describe(t)
        }
    }
}
