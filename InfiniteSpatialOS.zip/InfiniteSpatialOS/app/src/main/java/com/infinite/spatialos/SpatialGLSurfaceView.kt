package com.infinite.spatialos

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ViewConfiguration
import kotlin.math.abs

class SpatialGLSurfaceView(context: Context) : GLSurfaceView(context) {

    val spatialRenderer = SpatialRenderer(context.applicationContext)

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var lastX = 0f
    private var moved = false

    /** Touch that landed on an app panel: (panelId, MotionEvent action, u, v in 0..1). */
    var touchSink: ((Int, Int, Float, Float) -> Unit)? = null
    var frameSink: (() -> Unit)? = null
    private var grabbed: PanelManager.Panel? = null
    private var grabBar = false
    private var lastY = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = spatialRenderer.hitPanel(e.x, e.y)
                if (hit != null) {
                    grabbed = hit.panel
                    grabBar = hit.onBar
                    lastX = e.x
                    lastY = e.y
                    spatialRenderer.panelMgr.selectedId = hit.panel.id
                    if (!hit.onBar) {
                        touchSink?.invoke(hit.panel.id, MotionEvent.ACTION_DOWN, hit.u, hit.v)
                    } else {
                        frameSink?.invoke()
                    }
                    return true
                }
                grabbed = null
                downX = e.x
                lastX = e.x
                moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val g = grabbed
                if (g != null) {
                    if (grabBar) {
                        spatialRenderer.dragPanel(g, e.x - lastX, e.y - lastY)
                        lastX = e.x
                        lastY = e.y
                    } else {
                        val uv = spatialRenderer.panelUv(g, e.x, e.y)
                        if (uv != null) touchSink?.invoke(g.id, MotionEvent.ACTION_MOVE, uv[0], uv[1])
                    }
                    return true
                }
                val dx = e.x - lastX
                lastX = e.x
                if (abs(e.x - downX) > slop) moved = true
                if (moved) {
                    val step = -dx / (width * 0.05f)
                    queueEvent { spatialRenderer.scrollBy(step) }
                }
            }
            MotionEvent.ACTION_UP -> {
                val g = grabbed
                if (g != null) {
                    grabbed = null
                    if (!grabBar) {
                        val uv = spatialRenderer.panelUv(g, e.x, e.y)
                        if (uv != null) touchSink?.invoke(g.id, MotionEvent.ACTION_UP, uv[0], uv[1])
                    }
                    return true
                }
                val x = e.x
                val y = e.y
                if (moved) queueEvent { spatialRenderer.settle() }
                else queueEvent { spatialRenderer.handleTap(x, y) }
            }
            MotionEvent.ACTION_CANCEL -> {
                val g = grabbed
                if (g != null) {
                    grabbed = null
                    if (!grabBar) touchSink?.invoke(g.id, MotionEvent.ACTION_CANCEL, 0f, 0f)
                    return true
                }
                queueEvent { spatialRenderer.settle() }
            }
        }
        return true
    }

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        preserveEGLContextOnPause = true
        setRenderer(spatialRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
