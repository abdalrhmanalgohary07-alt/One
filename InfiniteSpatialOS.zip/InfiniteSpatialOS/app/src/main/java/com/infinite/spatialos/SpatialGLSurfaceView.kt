package com.infinite.spatialos

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ViewConfiguration
import kotlin.math.abs

class SpatialGLSurfaceView(context: Context) : GLSurfaceView(context) {

    private val spatialRenderer = SpatialRenderer(context.applicationContext)

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var lastX = 0f
    private var moved = false

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                lastX = e.x
                moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                lastX = e.x
                if (abs(e.x - downX) > slop) moved = true
                if (moved) {
                    val step = -dx / (width * 0.07f)
                    queueEvent { spatialRenderer.scrollBy(step) }
                }
            }
            MotionEvent.ACTION_UP -> {
                val x = e.x
                val y = e.y
                if (moved) queueEvent { spatialRenderer.settle() }
                else queueEvent { spatialRenderer.handleTap(x, y) }
            }
            MotionEvent.ACTION_CANCEL -> queueEvent { spatialRenderer.settle() }
        }
        return true
    }

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        preserveEGLContextOnPause = true
        setRenderer(spatialRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
