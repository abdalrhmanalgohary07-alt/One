package com.infinite.spatialos

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ViewConfiguration
import kotlin.math.abs

class SpatialGLSurfaceView(context: Context) : GLSurfaceView(context) {

    val spatialRenderer = SpatialRenderer(context.applicationContext)

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var lastX = 0f
    private var moved = false

    /** Receives touches that land on the app panel: (MotionEvent action, u, v) with u,v in 0..1. */
    var touchSink: ((Int, Float, Float) -> Unit)? = null
    private var panelMode = false

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val uv = spatialRenderer.panelUv(e.x, e.y, false)
                if (uv != null) {
                    panelMode = true
                    touchSink?.invoke(MotionEvent.ACTION_DOWN, uv[0], uv[1])
                    return true
                }
                panelMode = false
                downX = e.x
                lastX = e.x
                moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (panelMode) {
                    val uv = spatialRenderer.panelUv(e.x, e.y, true)
                    if (uv != null) touchSink?.invoke(MotionEvent.ACTION_MOVE, uv[0], uv[1])
                    return true
                }
                val dx = e.x - lastX
                lastX = e.x
                if (abs(e.x - downX) > slop) moved = true
                if (moved) {
                    val step = -dx / (width * 0.07f)
                    queueEvent { spatialRenderer.scrollBy(step) }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (panelMode) {
                    panelMode = false
                    val uv = spatialRenderer.panelUv(e.x, e.y, true)
                    if (uv != null) touchSink?.invoke(MotionEvent.ACTION_UP, uv[0], uv[1])
                    return true
                }
                val x = e.x
                val y = e.y
                if (moved) queueEvent { spatialRenderer.settle() }
                else queueEvent { spatialRenderer.handleTap(x, y) }
            }
            MotionEvent.ACTION_CANCEL -> {
                if (panelMode) {
                    panelMode = false
                    touchSink?.invoke(MotionEvent.ACTION_CANCEL, 0f, 0f)
                    return true
                }
                queueEvent { spatialRenderer.settle() }
            }
        }
        return true
    }

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        preserveEGLContextOnPause = true
        setRenderer(spatialRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
