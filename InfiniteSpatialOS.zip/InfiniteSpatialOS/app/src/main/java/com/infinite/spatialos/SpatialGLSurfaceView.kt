package com.infinite.spatialos

import android.content.Context
import android.opengl.GLSurfaceView
import android.os.SystemClock
import android.view.MotionEvent
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

class SpatialGLSurfaceView(context: Context) : GLSurfaceView(context) {

    val spatialRenderer = SpatialRenderer(context.applicationContext)

    /** Touch that landed on an app screen: (panelId, MotionEvent action, u, v in 0..1). */
    var touchSink: ((Int, Int, Float, Float) -> Unit)? = null

    /** A frame zone was touched (used to show the toolbar). */
    var frameSink: (() -> Unit)? = null

    /** The selected panel changed because of a touch. */
    var selectionSink: (() -> Unit)? = null

    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private var grabbed: PanelManager.Panel? = null
    private var grabZone = PanelManager.ZONE_BODY
    private var dockDrag = false
    private var moved = false
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f

    // two-finger gesture
    private var gesturePanel: PanelManager.Panel? = null
    private var gDist = 1f
    private var gAng = 0f
    private var gMidX = 0f
    private var gMidY = 0f
    private var gWidth = 1f
    private var gRoll = 0f
    private var gX = 0f
    private var gY = 0f

    private fun select(p: PanelManager.Panel) {
        val mgr = spatialRenderer.panelMgr
        if (mgr.selectedId != p.id) {
            mgr.selectedId = p.id
            selectionSink?.invoke()
        }
        mgr.labelsUntil = SystemClock.uptimeMillis() + 2500L
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gesturePanel = null
                grabbed = null
                dockDrag = false
                moved = false
                lastX = e.x
                lastY = e.y
                downY = e.y
                if (spatialRenderer.dockContains(e.x, e.y)) {
                    dockDrag = true
                    return true
                }
                val hit = spatialRenderer.hitPanel(e.x, e.y)
                if (hit != null) {
                    grabbed = hit.panel
                    grabZone = hit.zone
                    select(hit.panel)
                    if (hit.zone == PanelManager.ZONE_BODY) {
                        touchSink?.invoke(hit.panel.id, MotionEvent.ACTION_DOWN, hit.u, hit.v)
                    } else {
                        frameSink?.invoke()
                    }
                }
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2 && !dockDrag) {
                    val mx = (e.getX(0) + e.getX(1)) / 2f
                    val my = (e.getY(0) + e.getY(1)) / 2f
                    val target = grabbed ?: spatialRenderer.hitPanel(mx, my)?.panel
                    if (target != null) {
                        val g = grabbed
                        if (g != null && grabZone == PanelManager.ZONE_BODY) {
                            touchSink?.invoke(g.id, MotionEvent.ACTION_CANCEL, 0f, 0f)
                        }
                        grabbed = null
                        gesturePanel = target
                        select(target)
                        gDist = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)).coerceAtLeast(1f)
                        gAng = Math.toDegrees(
                            atan2(
                                (e.getY(0) - e.getY(1)).toDouble(),
                                (e.getX(0) - e.getX(1)).toDouble()
                            )
                        ).toFloat()
                        gMidX = mx
                        gMidY = my
                        gWidth = target.width
                        gRoll = target.roll
                        gX = target.x
                        gY = target.y
                        frameSink?.invoke()
                    }
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val gp = gesturePanel
                if (gp != null) {
                    if (e.pointerCount >= 2) {
                        val dist = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)).coerceAtLeast(1f)
                        val ang = Math.toDegrees(
                            atan2(
                                (e.getY(0) - e.getY(1)).toDouble(),
                                (e.getX(0) - e.getX(1)).toDouble()
                            )
                        ).toFloat()
                        var da = ang - gAng
                        while (da > 180f) da -= 360f
                        while (da < -180f) da += 360f
                        val mx = (e.getX(0) + e.getX(1)) / 2f
                        val my = (e.getY(0) + e.getY(1)) / 2f
                        spatialRenderer.panelMgr.gesture(
                            gp, gWidth, gRoll, gX, gY,
                            dist / gDist, -da, mx - gMidX, my - gMidY, height
                        )
                    }
                    return true
                }
                if (dockDrag) {
                    if (abs(e.y - downY) > slop) moved = true
                    if (moved) {
                        val rows = -(e.y - lastY) / spatialRenderer.dockCell()
                        queueEvent { spatialRenderer.scrollBy(rows) }
                    }
                    lastY = e.y
                    return true
                }
                val g = grabbed
                if (g != null) {
                    if (grabZone != PanelManager.ZONE_BODY) {
                        spatialRenderer.dragPanel(g, grabZone, e.x - lastX, e.y - lastY)
                        spatialRenderer.panelMgr.labelsUntil = SystemClock.uptimeMillis() + 1500L
                        lastX = e.x
                        lastY = e.y
                    } else {
                        val uv = spatialRenderer.panelUv(g, e.x, e.y)
                        if (uv != null) touchSink?.invoke(g.id, MotionEvent.ACTION_MOVE, uv[0], uv[1])
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (gesturePanel != null) {
                    gesturePanel = null
                    return true
                }
                if (dockDrag) {
                    dockDrag = false
                    val x = e.x
                    val y = e.y
                    if (moved) queueEvent { spatialRenderer.settle() }
                    else queueEvent { spatialRenderer.handleTap(x, y) }
                    return true
                }
                val g = grabbed
                if (g != null) {
                    grabbed = null
                    if (grabZone == PanelManager.ZONE_BODY) {
                        val uv = spatialRenderer.panelUv(g, e.x, e.y)
                        if (uv != null) touchSink?.invoke(g.id, MotionEvent.ACTION_UP, uv[0], uv[1])
                    }
                }
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                val g = grabbed
                if (g != null && grabZone == PanelManager.ZONE_BODY) {
                    touchSink?.invoke(g.id, MotionEvent.ACTION_CANCEL, 0f, 0f)
                }
                if (dockDrag) queueEvent { spatialRenderer.settle() }
                grabbed = null
                gesturePanel = null
                dockDrag = false
                return true
            }
        }
        return true
    }

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        preserveEGLContextOnPause = true
        setRenderer(spatialRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
