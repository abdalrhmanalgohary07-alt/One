package com.infinite.spatialos

import android.content.Context
import android.opengl.GLSurfaceView

class SpatialGLSurfaceView(context: Context) : GLSurfaceView(context) {

    private val spatialRenderer = SpatialRenderer(context.applicationContext)

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        preserveEGLContextOnPause = true
        setRenderer(spatialRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
