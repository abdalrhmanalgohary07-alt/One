package com.infinite.spatialos

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/** Connects to Shizuku, asks for permission, and binds [ShellService] with shell privileges. */
class ShizukuBridge(
    private val ctx: Context,
    private val onStatus: (String) -> Unit
) {
    @Volatile
    var service: IShellService? = null
        private set

    private val binderListener = Shizuku.OnBinderReceivedListener { check() }

    private val deadListener = Shizuku.OnBinderDeadListener {
        service = null
        onStatus("Shizuku وقف. شغّله من تاني")
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) bind()
        else onStatus("رفضت صلاحية Shizuku")
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                service = IShellService.Stub.asInterface(binder)
                onStatus("Shizuku متصل ✓ اضغط على أي تطبيق")
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            onStatus("الاتصال بـ Shizuku اتقطع")
        }
    }

    fun start() {
        onStatus("مستني Shizuku…")
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    fun stop() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
    }

    private fun check() {
        try {
            if (Shizuku.isPreV11()) {
                onStatus("نسخة Shizuku قديمة. حدّثها")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bind()
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                onStatus("صلاحية Shizuku مرفوضة. فعّلها من تطبيق Shizuku")
            } else {
                onStatus("وافق على طلب Shizuku")
                Shizuku.requestPermission(100)
            }
        } catch (t: Throwable) {
            onStatus("Shizuku: " + t.message)
        }
    }

    private fun bind() {
        try {
            onStatus("بيتصل بـ Shizuku…")
            val args = Shizuku.UserServiceArgs(
                ComponentName(ctx.packageName, ShellService::class.java.name)
            )
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(false)
                .version(1)
            Shizuku.bindUserService(args, conn)
        } catch (t: Throwable) {
            onStatus("bind: " + t.message)
        }
    }
}
