package com.infinite.spatialos

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : Activity() {

    companion object {
        private const val PANEL_W = 1280
        private const val PANEL_H = 800
        private const val PANEL_DPI = 240
    }

    private lateinit var glView: SpatialGLSurfaceView
    private lateinit var status: TextView
    private lateinit var closeBtn: Button
    private lateinit var bridge: ShizukuBridge

    @Volatile
    private var displayId = -1

    @Volatile
    private var creating = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = FrameLayout(this)
        glView = SpatialGLSurfaceView(this)
        root.addView(
            glView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#334155"))
            setBackgroundColor(Color.parseColor("#B0FFFFFF"))
            setPadding(24, 12, 24, 12)
            isClickable = false
        }
        root.addView(
            status,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply { setMargins(24, 24, 0, 0) }
        )

        closeBtn = Button(this).apply {
            text = "✕ اقفل الشاشة"
            visibility = View.GONE
            setOnClickListener { closePanel() }
        }
        root.addView(
            closeBtn,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply { setMargins(0, 24, 24, 0) }
        )

        setContentView(root)
        hideSystemBars()

        bridge = ShizukuBridge(this) { msg -> setStatus(msg) }
        glView.spatialRenderer.onAppTap = { pkg -> openApp(pkg) }
        bridge.start()
    }

    private fun setStatus(msg: String) {
        runOnUiThread { status.text = msg }
    }

    private fun openApp(pkg: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        val comp = launchIntent.component?.flattenToShortString()
        val svc = bridge.service
        if (svc == null || comp == null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(launchIntent)
            } catch (_: Throwable) {
            }
            return
        }

        if (displayId >= 0) {
            Thread {
                try {
                    val out = svc.launchApp(displayId, comp)
                    setStatus("الشاشة #$displayId: " + out.lines().firstOrNull().orEmpty())
                } catch (t: Throwable) {
                    setStatus("launch: " + t.message)
                }
            }.start()
            return
        }

        if (creating) return
        creating = true
        setStatus("بيجهّز الشاشة…")
        glView.queueEvent {
            glView.spatialRenderer.createPanel(PANEL_W, PANEL_H) { surface ->
                Thread {
                    try {
                        val id = svc.createDisplay(surface, PANEL_W, PANEL_H, PANEL_DPI)
                        if (id < 0) {
                            setStatus("فشل إنشاء الشاشة: " + svc.lastError())
                            glView.queueEvent { glView.spatialRenderer.releasePanel() }
                        } else {
                            displayId = id
                            val out = svc.launchApp(id, comp)
                            runOnUiThread {
                                closeBtn.visibility = View.VISIBLE
                                status.text = "الشاشة #$id: " + out.lines().firstOrNull().orEmpty()
                            }
                        }
                    } catch (t: Throwable) {
                        setStatus("خطأ: " + t.message)
                        glView.queueEvent { glView.spatialRenderer.releasePanel() }
                    } finally {
                        creating = false
                    }
                }.start()
            }
        }
    }

    private fun closePanel() {
        val svc = bridge.service
        displayId = -1
        closeBtn.visibility = View.GONE
        Thread {
            try {
                svc?.releaseDisplay()
            } catch (_: Throwable) {
            }
        }.start()
        glView.queueEvent { glView.spatialRenderer.releasePanel() }
        setStatus("الشاشة اتقفلت")
    }

    override fun onDestroy() {
        bridge.stop()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
    }

    override fun onPause() {
        glView.onPause()
        super.onPause()
    }
}
