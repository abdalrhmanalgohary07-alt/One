package com.infinite.spatialos

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        private const val PANEL_W = 1280
        private const val PANEL_H = 800
        private const val PANEL_DPI = 240
        private const val TOOLS_HIDE_MS = 5000L
    }

    private lateinit var glView: SpatialGLSurfaceView
    private lateinit var bridge: ShizukuBridge
    private lateinit var toggleBtn: TextView
    private lateinit var toolsPill: LinearLayout
    private lateinit var badge: View
    private lateinit var dockBtn: TextView
    private lateinit var logOverlay: FrameLayout
    private lateinit var logText: TextView
    private val modeButtons = ArrayList<Pair<Int, TextView>>()
    private val main = Handler(Looper.getMainLooper())
    private val hideTools = Runnable { setToolsShown(false) }
    private var toolsShown = false
    private var touchDownTime = 0L
    private var lastSvcError = ""

    @Volatile
    private var pending = 0

    private val mgr: PanelManager get() = glView.spatialRenderer.panelMgr

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setupCrashLog()

        val root = FrameLayout(this)
        glView = SpatialGLSurfaceView(this)
        root.addView(
            glView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        // ---- top-left: notifications bell + dock toggle
        val topLeft = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bell = roundBtn("🔔") { showLog() }
        badge = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#EF4444"))
            }
            visibility = View.GONE
        }
        val bellBox = FrameLayout(this)
        bellBox.addView(bell)
        bellBox.addView(
            badge,
            FrameLayout.LayoutParams(dp(12), dp(12), Gravity.TOP or Gravity.END)
                .apply { setMargins(0, dp(2), dp(2), 0) }
        )
        dockBtn = roundBtn("☰") { toggleDock() }
        topLeft.addView(bellBox)
        topLeft.addView(dockBtn)
        root.addView(
            topLeft,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply { setMargins(dp(10), dp(10), 0, 0) }
        )

        // ---- top-right: show/hide button + toolbar pill (only while screens are open)
        val topRight = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        toggleBtn = roundBtn("⋯") { setToolsShown(!toolsShown) }
        toggleBtn.visibility = View.GONE
        topRight.addView(toggleBtn)

        toolsPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                setColor(Color.parseColor("#D91E293B"))
            }
            visibility = View.GONE
            alpha = 0f
        }
        toolsPill.addView(roundBtn("◀", 40) { sendKey(KeyEvent.KEYCODE_BACK) })
        toolsPill.addView(roundBtn("⌂", 40) { sendKey(KeyEvent.KEYCODE_HOME) })
        toolsPill.addView(roundBtn("✕", 40, "#B91C1C") { closeSelected() })
        toolsPill.addView(View(this), LinearLayout.LayoutParams(dp(1), dp(24)).apply {
            setMargins(dp(6), 0, dp(6), 0)
        })
        val defs = listOf(
            PanelManager.MODE_MOVE to "تحريك",
            PanelManager.MODE_SIZE to "حجم",
            PanelManager.MODE_ROTATE to "دوران",
            PanelManager.MODE_ROLL to "ميل",
            PanelManager.MODE_DEPTH to "عمق"
        )
        for ((mode, label) in defs) {
            val b = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                gravity = Gravity.CENTER
                setPadding(dp(12), 0, dp(12), 0)
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    setColor(Color.TRANSPARENT)
                }
                setOnClickListener { setMode(mode) }
            }
            modeButtons.add(mode to b)
            toolsPill.addView(
                b,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36))
                    .apply { setMargins(dp(2), 0, dp(2), 0) }
            )
        }
        topRight.addView(
            toolsPill,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )
        root.addView(
            topRight,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply { setMargins(0, dp(10), dp(10), 0) }
        )
        setMode(PanelManager.MODE_MOVE)

        // ---- log overlay
        logOverlay = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#66000000"))
            visibility = View.GONE
            isClickable = true
            setOnClickListener { hideLog() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            isClickable = true
            background = GradientDrawable().apply {
                cornerRadius = dp(22).toFloat()
                setColor(Color.parseColor("#F2111827"))
            }
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(
            TextView(this).apply {
                text = "الإشعارات والأخطاء"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                typeface = Typeface.DEFAULT_BOLD
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(pill("نسخ") { copyLog() })
        head.addView(pill("مسح") { AppLog.clear(); refreshLog() })
        head.addView(pill("إغلاق") { hideLog() })
        card.addView(head)
        logText = TextView(this).apply {
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(0, dp(10), 0, 0)
        }
        val scroll = ScrollView(this)
        scroll.addView(logText)
        card.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        )
        logOverlay.addView(
            card,
            FrameLayout.LayoutParams(dp(620), dp(400), Gravity.CENTER)
        )
        root.addView(
            logOverlay,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        setContentView(root)
        hideSystemBars()

        AppLog.onChange = {
            runOnUiThread {
                badge.visibility = if (AppLog.unseenErrors > 0) View.VISIBLE else View.GONE
                if (logOverlay.visibility == View.VISIBLE) refreshLog()
            }
        }

        bridge = ShizukuBridge(this) { msg -> report(msg) }
        glView.spatialRenderer.onAppTap = { pkg -> openApp(pkg) }
        glView.touchSink = { id, action, u, v -> sendTouch(id, action, u, v) }
        glView.frameSink = { runOnUiThread { setToolsShown(true) } }
        bridge.start()
    }

    // ------------------------------------------------------------------ UI helpers

    private fun roundBtn(
        label: String,
        sizeDp: Int = 44,
        color: String = "#CC1E293B",
        onClick: () -> Unit
    ): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(color))
        }
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
            .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        setOnClickListener { onClick() }
    }

    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(7), dp(14), dp(7))
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(Color.parseColor("#334155"))
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(4), 0, 0, 0) }
        setOnClickListener { onClick() }
    }

    private fun setMode(mode: Int) {
        mgr.dragMode = mode
        for ((m, b) in modeButtons) {
            (b.background as GradientDrawable).setColor(
                if (m == mode) Color.parseColor("#3B82F6") else Color.TRANSPARENT
            )
        }
        scheduleHide()
    }

    private fun setToolsShown(show: Boolean) {
        if (show && mgr.panels.isEmpty()) return
        toolsShown = show
        main.removeCallbacks(hideTools)
        if (show) {
            toolsPill.visibility = View.VISIBLE
            toolsPill.animate().alpha(1f).translationY(0f).setDuration(160).start()
            scheduleHide()
        } else {
            toolsPill.animate().alpha(0f).translationY(-dp(8).toFloat()).setDuration(160)
                .withEndAction { if (!toolsShown) toolsPill.visibility = View.GONE }
                .start()
        }
    }

    private fun scheduleHide() {
        main.removeCallbacks(hideTools)
        if (toolsShown) main.postDelayed(hideTools, TOOLS_HIDE_MS)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (toolsShown) scheduleHide()
        return super.dispatchTouchEvent(ev)
    }

    private fun toggleDock() {
        val r = glView.spatialRenderer
        r.dockVisible = !r.dockVisible
        dockBtn.alpha = if (r.dockVisible) 1f else 0.5f
    }

    // ------------------------------------------------------------------ log

    private fun isErrorText(msg: String): Boolean =
        listOf("فشل", "خطأ", "رفضت", "مرفوضة", "bind:", "Shizuku:", "قديمة", "اتقطع", "وقف")
            .any { msg.contains(it) }

    private fun report(msg: String) = AppLog.add(isErrorText(msg), msg)

    private fun setupCrashLog() {
        val prefs = getSharedPreferences("log", MODE_PRIVATE)
        prefs.getString("crash", null)?.let {
            AppLog.add(true, "آخر انهيار:\n$it")
            prefs.edit().remove("crash").apply()
        }
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                prefs.edit().putString("crash", Log.getStackTraceString(e).take(1500)).commit()
            } catch (_: Throwable) {
            }
            old?.uncaughtException(t, e)
        }
    }

    private fun showLog() {
        logOverlay.visibility = View.VISIBLE
        AppLog.markSeen()
        refreshLog()
        // also pull the last error recorded inside the Shizuku service
        val svc = bridge.service ?: return
        Thread {
            try {
                val e = svc.lastError()
                if (e.isNotEmpty() && e != lastSvcError) {
                    lastSvcError = e
                    AppLog.add(true, "الخدمة: $e")
                    AppLog.markSeen()
                }
            } catch (_: Throwable) {
            }
        }.start()
    }

    private fun hideLog() {
        logOverlay.visibility = View.GONE
    }

    private fun formatLog(): String {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        val list = AppLog.snapshot()
        if (list.isEmpty()) return "مفيش إشعارات"
        return list.asReversed().joinToString("\n\n") {
            (if (it.isError) "⚠ " else "• ") + fmt.format(Date(it.time)) + "  " + it.text
        }
    }

    private fun refreshLog() {
        logText.text = formatLog()
    }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", formatLog()))
        AppLog.add(false, "اتنسخ السجل")
    }

    // ------------------------------------------------------------------ panels

    private fun selectedPanel(): PanelManager.Panel? = mgr.find(mgr.selectedId)

    private fun openApp(pkg: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        val comp = launchIntent.component?.flattenToShortString()
        val svc = bridge.service
        if (svc == null || comp == null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(launchIntent)
            } catch (_: Throwable) {
            }
            return
        }
        if (mgr.panels.size + pending >= PanelManager.MAX_PANELS) {
            report("اقفل شاشة الأول (الحد الأقصى ${PanelManager.MAX_PANELS})")
            return
        }
        pending++
        glView.queueEvent {
            glView.spatialRenderer.createPanel(PANEL_W, PANEL_H) { panelId, surface ->
                Thread {
                    try {
                        val id = svc.createDisplay(surface, PANEL_W, PANEL_H, PANEL_DPI)
                        if (id < 0) {
                            report("فشل إنشاء الشاشة: " + svc.lastError())
                            glView.queueEvent { glView.spatialRenderer.removePanel(panelId) }
                        } else {
                            mgr.find(panelId)?.displayId = id
                            val out = svc.launchApp(id, comp)
                            AppLog.add(
                                out.contains("Error", true),
                                "شاشة #$id ($comp):\n$out"
                            )
                            runOnUiThread {
                                toggleBtn.visibility = View.VISIBLE
                                setToolsShown(true)
                            }
                        }
                    } catch (t: Throwable) {
                        report("خطأ: " + t.message)
                        glView.queueEvent { glView.spatialRenderer.removePanel(panelId) }
                    } finally {
                        pending--
                    }
                }.start()
            }
        }
    }

    private fun sendTouch(panelId: Int, action: Int, u: Float, v: Float) {
        val svc = bridge.service ?: return
        val id = mgr.find(panelId)?.displayId ?: return
        if (id < 0) return
        if (action == MotionEvent.ACTION_DOWN) touchDownTime = SystemClock.uptimeMillis()
        try {
            svc.injectTouch(id, action, u * PANEL_W, v * PANEL_H, touchDownTime)
        } catch (_: Throwable) {
        }
    }

    private fun sendKey(code: Int) {
        scheduleHide()
        val svc = bridge.service ?: return
        val id = selectedPanel()?.displayId ?: return
        if (id < 0) return
        Thread {
            try {
                svc.injectKey(id, KeyEvent.ACTION_DOWN, code, 0)
                svc.injectKey(id, KeyEvent.ACTION_UP, code, 0)
            } catch (_: Throwable) {
            }
        }.start()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val svc = bridge.service
        val id = selectedPanel()?.displayId ?: -1
        val code = event.keyCode
        val system = code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_HOME ||
            code == KeyEvent.KEYCODE_APP_SWITCH || code == KeyEvent.KEYCODE_POWER ||
            code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN
        if (svc != null && id >= 0 && !system) {
            try {
                svc.injectKey(id, event.action, code, event.metaState)
            } catch (_: Throwable) {
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun closeSelected() {
        val p = selectedPanel() ?: return
        val svc = bridge.service
        val displayId = p.displayId
        val panelId = p.id
        Thread {
            try {
                if (displayId >= 0) svc?.releaseDisplay(displayId)
            } catch (_: Throwable) {
            }
        }.start()
        glView.queueEvent {
            glView.spatialRenderer.removePanel(panelId)
            runOnUiThread {
                if (mgr.panels.isEmpty()) {
                    setToolsShown(false)
                    toggleBtn.visibility = View.GONE
                }
            }
        }
    }

    override fun onDestroy() {
        AppLog.onChange = null
        bridge.stop()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
    }

    override fun onPause() {
        glView.onPause()
        super.onPause()
    }
}
