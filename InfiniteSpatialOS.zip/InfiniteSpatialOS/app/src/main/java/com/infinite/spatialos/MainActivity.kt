package com.infinite.spatialos

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : Activity() {

    companion object {
        private const val PANEL_W = 1280
        private const val PANEL_H = 800
        private const val PANEL_DPI = 240
    }

    private lateinit var glView: SpatialGLSurfaceView
    private lateinit var status: TextView
    private lateinit var tools: LinearLayout
    private lateinit var bridge: ShizukuBridge
    private val modeButtons = ArrayList<Pair<Int, Button>>()
    private var touchDownTime = 0L

    @Volatile
    private var pending = 0

    private val mgr: PanelManager get() = glView.spatialRenderer.panelMgr

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = FrameLayout(this)
        glView = SpatialGLSurfaceView(this)
        root.addView(
            glView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#334155"))
            setBackgroundColor(Color.parseColor("#B0FFFFFF"))
            setPadding(24, 12, 24, 12)
            isClickable = false
        }
        root.addView(
            status,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).apply { setMargins(24, 24, 0, 0) }
        )

        // Toolbar for the selected panel (blue title bar)
        tools = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            visibility = View.GONE
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "◀"
            setOnClickListener { sendKey(KeyEvent.KEYCODE_BACK) }
        })
        actions.addView(Button(this).apply {
            text = "⌂"
            setOnClickListener { sendKey(KeyEvent.KEYCODE_HOME) }
        })
        actions.addView(Button(this).apply {
            text = "✕ اقفل"
            setOnClickListener { closeSelected() }
        })
        tools.addView(actions)

        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val defs = listOf(
            PanelManager.MODE_MOVE to "تحريك",
            PanelManager.MODE_SIZE to "حجم",
            PanelManager.MODE_ROTATE to "دوران",
            PanelManager.MODE_ROLL to "ميل",
            PanelManager.MODE_DEPTH to "عمق"
        )
        for ((mode, label) in defs) {
            val b = Button(this).apply {
                text = label
                setOnClickListener { setMode(mode) }
            }
            modeButtons.add(mode to b)
            modes.addView(b)
        }
        tools.addView(modes)
        root.addView(
            tools,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply { setMargins(0, 24, 24, 0) }
        )
        setMode(PanelManager.MODE_MOVE)

        setContentView(root)
        hideSystemBars()

        bridge = ShizukuBridge(this) { msg -> setStatus(msg) }
        glView.spatialRenderer.onAppTap = { pkg -> openApp(pkg) }
        glView.touchSink = { id, action, u, v -> sendTouch(id, action, u, v) }
        bridge.start()
    }

    private fun setMode(mode: Int) {
        mgr.dragMode = mode
        for ((m, b) in modeButtons) {
            b.alpha = if (m == mode) 1f else 0.55f
            b.text = (if (m == mode) "● " else "") + b.text.toString().removePrefix("● ")
        }
    }

    private fun setStatus(msg: String) {
        runOnUiThread { status.text = msg }
    }

    private fun selectedPanel(): PanelManager.Panel? = mgr.find(mgr.selectedId)

    private fun openApp(pkg: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        val comp = launchIntent.component?.flattenToShortString()
        val svc = bridge.service
        if (svc == null || comp == null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(launchIntent)
            } catch (_: Throwable) {
            }
            return
        }
        if (mgr.panels.size + pending >= PanelManager.MAX_PANELS) {
            setStatus("اقفل شاشة الأول (الحد الأقصى ${PanelManager.MAX_PANELS})")
            return
        }
        pending++
        setStatus("بيجهّز الشاشة…")
        glView.queueEvent {
            glView.spatialRenderer.createPanel(PANEL_W, PANEL_H) { panelId, surface ->
                Thread {
                    try {
                        val id = svc.createDisplay(surface, PANEL_W, PANEL_H, PANEL_DPI)
                        if (id < 0) {
                            setStatus("فشل إنشاء الشاشة: " + svc.lastError())
                            glView.queueEvent { glView.spatialRenderer.removePanel(panelId) }
                        } else {
                            mgr.find(panelId)?.displayId = id
                            val out = svc.launchApp(id, comp)
                            runOnUiThread {
                                tools.visibility = View.VISIBLE
                                status.text = "شاشة #$id: " + out.lines().firstOrNull().orEmpty()
                            }
                        }
                    } catch (t: Throwable) {
                        setStatus("خطأ: " + t.message)
                        glView.queueEvent { glView.spatialRenderer.removePanel(panelId) }
                    } finally {
                        pending--
                    }
                }.start()
            }
        }
    }

    private fun sendTouch(panelId: Int, action: Int, u: Float, v: Float) {
        val svc = bridge.service ?: return
        val id = mgr.find(panelId)?.displayId ?: return
        if (id < 0) return
        if (action == MotionEvent.ACTION_DOWN) touchDownTime = SystemClock.uptimeMillis()
        try {
            svc.injectTouch(id, action, u * PANEL_W, v * PANEL_H, touchDownTime)
        } catch (_: Throwable) {
        }
    }

    private fun sendKey(code: Int) {
        val svc = bridge.service ?: return
        val id = selectedPanel()?.displayId ?: return
        if (id < 0) return
        Thread {
            try {
                svc.injectKey(id, KeyEvent.ACTION_DOWN, code, 0)
                svc.injectKey(id, KeyEvent.ACTION_UP, code, 0)
            } catch (_: Throwable) {
            }
        }.start()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val svc = bridge.service
        val id = selectedPanel()?.displayId ?: -1
        val code = event.keyCode
        val system = code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_HOME ||
            code == KeyEvent.KEYCODE_APP_SWITCH || code == KeyEvent.KEYCODE_POWER ||
            code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN
        if (svc != null && id >= 0 && !system) {
            try {
                svc.injectKey(id, event.action, code, event.metaState)
            } catch (_: Throwable) {
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun closeSelected() {
        val p = selectedPanel() ?: return
        val svc = bridge.service
        val displayId = p.displayId
        val panelId = p.id
        Thread {
            try {
                if (displayId >= 0) svc?.releaseDisplay(displayId)
            } catch (_: Throwable) {
            }
        }.start()
        glView.queueEvent {
            glView.spatialRenderer.removePanel(panelId)
            runOnUiThread {
                if (mgr.panels.isEmpty()) tools.visibility = View.GONE
            }
        }
        setStatus("الشاشة اتقفلت")
    }

    override fun onDestroy() {
        bridge.stop()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        glView.onResume()
    }

    override fun onPause() {
        glView.onPause()
        super.onPause()
    }
}
