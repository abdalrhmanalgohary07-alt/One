package com.infinite.spatialos

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/**
 * Pure layout math for the curved dock (no OpenGL here).
 * [center] is a float index: the icon at that index sits in front of the user.
 * Only icons within [VISIBLE_RANGE] of the center are returned.
 */
object DockLayout {

    const val RADIUS = 3.6f
    const val BASE_SIZE = 0.5f
    const val DOCK_Y = -1.3f
    const val FLOOR_Y = -2.0f
    const val VISIBLE_RANGE = 4.6f
    private const val GAP = 0.07f
    private const val SHRINK_PER_STEP = 0.16f
    private const val DROP_REF_ANGLE = 0.46f
    private const val MAX_EDGE_DROP = 0.14f

    data class Slot(
        val index: Int,
        val x: Float,
        val y: Float,
        val z: Float,
        val yawDeg: Float,
        val size: Float,
        val angleRad: Float
    )

    fun compute(count: Int, centerIn: Float): List<Slot> {
        if (count <= 0) return emptyList()
        val center = centerIn.coerceIn(0f, (count - 1).toFloat())
        val lo = ceil(center - VISIBLE_RANGE).toInt().coerceAtLeast(0)
        val hi = floor(center + VISIBLE_RANGE).toInt().coerceAtMost(count - 1)
        val n = hi - lo + 1

        val scale = FloatArray(n) { 1f / (1f + SHRINK_PER_STEP * abs(lo + it - center)) }
        val size = FloatArray(n) { BASE_SIZE * scale[it] }

        val arc = FloatArray(n)
        for (i in 1 until n) {
            arc[i] = arc[i - 1] +
                (size[i - 1] + size[i]) / 2f +
                GAP * (scale[i - 1] + scale[i]) / 2f
        }

        val fl = floor(center).toInt()
        val a0 = (fl - lo).coerceIn(0, n - 1)
        val a1 = (a0 + 1).coerceAtMost(n - 1)
        val frac = center - fl
        val mid = arc[a0] + (arc[a1] - arc[a0]) * frac

        return List(n) { i ->
            val theta = (arc[i] - mid) / RADIUS
            val f = (abs(theta) / DROP_REF_ANGLE).coerceAtMost(1.5f)
            Slot(
                index = lo + i,
                x = RADIUS * sin(theta),
                y = DOCK_Y - MAX_EDGE_DROP * f * f,
                z = -RADIUS * cos(theta),
                yawDeg = Math.toDegrees((-theta).toDouble()).toFloat(),
                size = size[i],
                angleRad = theta
            )
        }
    }
}
