package com.infinite.spatialos

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Pure layout math for the curved dock (no OpenGL here, so it is easy to test).
 * The user stands at the origin; icons sit on a circle of radius [RADIUS] in front of them.
 * Icons shrink with distance from the center so the center reads larger and clearer.
 */
object DockLayout {

    const val RADIUS = 3.6f
    const val BASE_SIZE = 0.5f
    const val DOCK_Y = -1.3f
    const val FLOOR_Y = -2.0f
    private const val GAP = 0.07f
    private const val SHRINK_PER_STEP = 0.16f
    private const val DROP_REF_ANGLE = 0.46f
    private const val MAX_EDGE_DROP = 0.14f

    data class Slot(
        val x: Float,
        val y: Float,
        val z: Float,
        val yawDeg: Float,
        val size: Float,
        val angleRad: Float
    )

    fun compute(count: Int): List<Slot> {
        if (count <= 0) return emptyList()
        val center = (count - 1) / 2f

        val scale = FloatArray(count) { 1f / (1f + SHRINK_PER_STEP * abs(it - center)) }
        val size = FloatArray(count) { BASE_SIZE * scale[it] }

        val arc = FloatArray(count)
        for (i in 1 until count) {
            arc[i] = arc[i - 1] +
                (size[i - 1] + size[i]) / 2f +
                GAP * (scale[i - 1] + scale[i]) / 2f
        }
        val mid = (arc[0] + arc[count - 1]) / 2f

        return List(count) { i ->
            val theta = (arc[i] - mid) / RADIUS
            val f = (abs(theta) / DROP_REF_ANGLE).coerceAtMost(1.5f)
            Slot(
                x = RADIUS * sin(theta),
                y = DOCK_Y - MAX_EDGE_DROP * f * f,
                z = -RADIUS * cos(theta),
                yawDeg = Math.toDegrees((-theta).toDouble()).toFloat(),
                size = size[i],
                angleRad = theta
            )
        }
    }
}
