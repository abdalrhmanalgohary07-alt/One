package com.infinite.spatialos;

import android.content.Context;
import android.content.ContextWrapper;

/** Pretends to be the shell package so DisplayManager accepts calls from the shell uid. */
public class FakeContext extends ContextWrapper {
    public FakeContext(Context base) {
        super(base);
    }

    @Override
    public String getPackageName() {
        return "com.android.shell";
    }

    // Hidden in the public SDK, so no @Override here; at runtime it still overrides.
    public String getOpPackageName() {
        return "com.android.shell";
    }

    @Override
    public Context getApplicationContext() {
        return this;
    }
}
