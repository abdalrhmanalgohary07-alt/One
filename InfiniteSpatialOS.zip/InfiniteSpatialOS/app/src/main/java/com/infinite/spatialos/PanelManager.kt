package com.infinite.spatialos

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.Matrix
import android.view.Surface
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Owns every floating app panel: textures, placement, drawing, hit-testing and dragging. */
class PanelManager {

    companion object {
        const val MAX_PANELS = 3
        const val ZONE_BODY = -1
        const val MODE_MOVE = 0
        const val MODE_SIZE = 1
        const val MODE_ROTATE = 2
        const val MODE_ROLL = 3
        const val MODE_DEPTH = 4
        private const val RING = 3.9f
        private const val BASE_Y = 0.3f
        private const val FRAME_M = 0.09f
        private const val HIT_M = 0.16f
        private const val TAN_HALF_FOV = 0.4452f
    }

    class Panel(val id: Int, val w: Int, val h: Int) {
        @Volatile var displayId = -1
        var tex = 0
        var st: SurfaceTexture? = null
        var surface: Surface? = null
        @Volatile var frame = false
        @Volatile var hasFrame = false
        val stMatrix = FloatArray(16)
        @Volatile var x = 0f
        @Volatile var y = BASE_Y
        @Volatile var z = -RING
        @Volatile var yaw = 0f
        @Volatile var pitch = 0f
        @Volatile var roll = 0f
        @Volatile var width = 2.3f
        @Volatile var moved = false
        @Volatile var pkg: String? = null
        val aspect: Float get() = w.toFloat() / h.toFloat()
    }

    class Hit(val panel: Panel, val zone: Int, val u: Float, val v: Float)

    val panels = CopyOnWriteArrayList<Panel>()
    @Volatile var selectedId = -1
    @Volatile var labelsUntil = 0L
    private var nextId = 1

    private var program = 0
    private val uni = HashMap<String, Int>()
    private val m = FloatArray(16)

    fun init() {
        program = compileProgram(PanelShaders.VERTEX, PanelShaders.FRAGMENT)
        uni.clear()
        for (n in listOf("uVP", "uModel", "uTex", "uSTMatrix", "uSolid", "uSize", "uRadius")) {
            uni[n] = GLES30.glGetUniformLocation(program, n)
        }
    }

    fun find(id: Int): Panel? = panels.firstOrNull { it.id == id }

    /** GL thread. */
    fun create(w: Int, h: Int): Panel {
        val p = Panel(nextId++, w, h)
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        p.tex = ids[0]
        val target = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(target, p.tex)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val st = SurfaceTexture(p.tex)
        st.setDefaultBufferSize(w, h)
        st.setOnFrameAvailableListener { p.frame = true }
        p.st = st
        p.surface = Surface(st)
        panels.add(p)
        selectedId = p.id
        labelsUntil = android.os.SystemClock.uptimeMillis() + 3000L
        relayout()
        return p
    }

    /** GL thread. */
    fun remove(id: Int) {
        val p = find(id) ?: return
        try {
            p.surface?.release()
            p.st?.release()
        } catch (_: Throwable) {
        }
        p.surface = null
        p.st = null
        p.hasFrame = false
        if (p.tex != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(p.tex), 0)
            p.tex = 0
        }
        panels.remove(p)
        if (selectedId == id) selectedId = panels.lastOrNull()?.id ?: -1
        relayout()
    }

    private fun relayout() {
        val list = panels.toList()
        val n = list.size
        if (n == 0) return
        val angles: FloatArray
        val width: Float
        when (n) {
            1 -> { angles = floatArrayOf(0f); width = 2.3f }
            2 -> { angles = floatArrayOf(-13.5f, 13.5f); width = 1.7f }
            else -> { angles = floatArrayOf(-23f, 0f, 23f); width = 1.55f }
        }
        for ((i, p) in list.withIndex()) {
            if (p.moved) continue
            val a = Math.toRadians(angles[i].toDouble())
            p.x = (RING * sin(a)).toFloat()
            p.z = (-RING * cos(a)).toFloat()
            p.yaw = -angles[i]
            p.pitch = 0f
            p.roll = 0f
            p.y = BASE_Y
            p.width = width
        }
    }

    private fun base(p: Panel, out: FloatArray) {
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, p.x, p.y, p.z)
        Matrix.rotateM(out, 0, p.yaw, 0f, 1f, 0f)
        Matrix.rotateM(out, 0, p.pitch, 1f, 0f, 0f)
        Matrix.rotateM(out, 0, p.roll, 0f, 0f, 1f)
    }

    private fun bodyModel(p: Panel, out: FloatArray) {
        base(p, out)
        Matrix.scaleM(out, 0, p.width, p.width / p.aspect, 1f)
    }

    private fun frameModel(p: Panel, out: FloatArray, margin: Float) {
        base(p, out)
        Matrix.scaleM(out, 0, p.width + 2f * margin, p.width / p.aspect + 2f * margin, 1f)
    }

    /** GL thread. The unit quad VAO must already be bound. */
    fun draw(vp: FloatArray) {
        if (panels.isEmpty()) return
        GLES30.glUseProgram(program)
        GLES30.glUniformMatrix4fv(uni.getValue("uVP"), 1, false, vp, 0)
        GLES30.glUniform1i(uni.getValue("uTex"), 0)
        for (p in panels.sortedBy { it.z }) {
            val st = p.st ?: continue
            if (p.frame) {
                p.frame = false
                try {
                    st.updateTexImage()
                    st.getTransformMatrix(p.stMatrix)
                    p.hasFrame = true
                } catch (_: Throwable) {
                }
            }
            if (!p.hasFrame) continue

            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, p.tex)

            bodyModel(p, m)
            GLES30.glUniformMatrix4fv(uni.getValue("uModel"), 1, false, m, 0)
            GLES30.glUniformMatrix4fv(uni.getValue("uSTMatrix"), 1, false, p.stMatrix, 0)
            GLES30.glUniform4f(uni.getValue("uSolid"), 0f, 0f, 0f, 0f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

            val sel = p.id == selectedId
            val bw = p.width
            val bh = p.width / p.aspect

            // translucent frame behind the screen (also the handle for moving/resizing)
            frameModel(p, m, FRAME_M)
            GLES30.glUniformMatrix4fv(uni.getValue("uModel"), 1, false, m, 0)
            GLES30.glUniform2f(uni.getValue("uSize"), bw + 2f * FRAME_M, bh + 2f * FRAME_M)
            GLES30.glUniform1f(uni.getValue("uRadius"), 0.11f)
            if (sel) GLES30.glUniform4f(uni.getValue("uSolid"), 0.27f, 0.55f, 1f, 0.55f)
            else GLES30.glUniform4f(uni.getValue("uSolid"), 1f, 1f, 1f, 0.16f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

            // the app screen with rounded corners
            bodyModel(p, m)
            GLES30.glUniformMatrix4fv(uni.getValue("uModel"), 1, false, m, 0)
            GLES30.glUniformMatrix4fv(uni.getValue("uSTMatrix"), 1, false, p.stMatrix, 0)
            GLES30.glUniform2f(uni.getValue("uSize"), bw, bh)
            GLES30.glUniform1f(uni.getValue("uRadius"), 0.07f)
            GLES30.glUniform4f(uni.getValue("uSolid"), 0f, 0f, 0f, 0f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        }
    }

    private fun unproject(inv: FloatArray, nx: Float, ny: Float, nz: Float): FloatArray {
        val o = FloatArray(4)
        Matrix.multiplyMV(o, 0, inv, 0, floatArrayOf(nx, ny, nz, 1f), 0)
        return floatArrayOf(o[0] / o[3], o[1] / o[3], o[2] / o[3])
    }

    /** Intersects the screen point with the unit quad of [model]; returns local (x, y) or null. */
    private fun localHit(vp: FloatArray, model: FloatArray, sx: Float, sy: Float, vw: Int, vh: Int): FloatArray? {
        val mvp = FloatArray(16)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        val inv = FloatArray(16)
        if (!Matrix.invertM(inv, 0, mvp, 0)) return null
        val nx = sx / vw * 2f - 1f
        val ny = 1f - sy / vh * 2f
        val a = unproject(inv, nx, ny, -1f)
        val b = unproject(inv, nx, ny, 1f)
        val dz = b[2] - a[2]
        if (abs(dz) < 1e-6f) return null
        val t = -a[2] / dz
        return floatArrayOf(a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))
    }

    /**
     * UI thread. Which panel is under the finger and which part of it: its screen
     * ([ZONE_BODY]) or one of the frame zones (a MODE_* value that says what dragging does).
     */
    fun hitTest(vp: FloatArray, sx: Float, sy: Float, vw: Int, vh: Int): Hit? {
        val tmp = FloatArray(16)
        for (p in panels.sortedByDescending { it.z }) {
            if (!p.hasFrame) continue
            bodyModel(p, tmp)
            val l = localHit(vp, tmp, sx, sy, vw, vh) ?: continue
            val lx = l[0]
            val ly = l[1]
            if (abs(lx) <= 0.5f && abs(ly) <= 0.5f) {
                return Hit(p, ZONE_BODY, lx + 0.5f, 0.5f - ly)
            }
            val ex = 0.5f + HIT_M / p.width
            val ey = 0.5f + HIT_M / (p.width / p.aspect)
            if (abs(lx) <= ex && abs(ly) <= ey) {
                val nx = lx / 0.5f
                val ny = ly / 0.5f
                val zone = when {
                    ly < -0.5f -> MODE_ROTATE
                    ly > 0.5f -> if (nx < -0.6f) MODE_SIZE else MODE_MOVE
                    lx < -0.5f -> if (ny > 0.55f) MODE_SIZE else MODE_ROLL
                    lx > 0.5f -> MODE_DEPTH
                    else -> MODE_MOVE
                }
                return Hit(p, zone, 0f, 0f)
            }
        }
        return null
    }

    /** UI thread. Same as [hitTest] but for an already-grabbed panel; clamps to its edges. */
    fun uvOn(p: Panel, vp: FloatArray, sx: Float, sy: Float, vw: Int, vh: Int): FloatArray? {
        val tmp = FloatArray(16)
        bodyModel(p, tmp)
        val l = localHit(vp, tmp, sx, sy, vw, vh) ?: return null
        return floatArrayOf((l[0] + 0.5f).coerceIn(0f, 1f), (0.5f - l[1]).coerceIn(0f, 1f))
    }

    /** UI thread. Applies a drag of one frame zone. */
    fun drag(p: Panel, zone: Int, dx: Float, dy: Float, vh: Int) {
        val upp = 2f * abs(p.z) * TAN_HALF_FOV / vh.coerceAtLeast(1)
        when (zone) {
            MODE_MOVE -> {
                p.x += dx * upp
                p.y -= dy * upp
            }
            MODE_SIZE -> p.width = (p.width + (-dx - dy) * upp * 0.9f).coerceIn(0.5f, 7f)
            MODE_ROTATE -> {
                p.yaw += dx * 0.25f
                p.pitch += dy * 0.25f
            }
            MODE_ROLL -> p.roll += -dy * 0.3f
            MODE_DEPTH -> p.z = (p.z + dy * upp * 2f).coerceIn(-14f, -1.6f)
        }
        p.moved = true
    }

    /** UI thread. Two-finger gesture: pinch = size, twist = tilt, drag = move. */
    fun gesture(
        p: Panel, width0: Float, roll0: Float, x0: Float, y0: Float,
        scale: Float, twistDeg: Float, dxPx: Float, dyPx: Float, vh: Int
    ) {
        val upp = 2f * abs(p.z) * TAN_HALF_FOV / vh.coerceAtLeast(1)
        p.width = (width0 * scale).coerceIn(0.5f, 7f)
        p.roll = roll0 + twistDeg
        p.x = x0 + dxPx * upp
        p.y = y0 - dyPx * upp
        p.moved = true
    }

    /** GL thread. A flat rounded rectangle in whatever space [vp] describes (pixels for the UI). */
    fun drawRoundRect(
        vp: FloatArray, cx: Float, cy: Float, w: Float, h: Float, radius: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        if (a <= 0f) return
        GLES30.glUseProgram(program)
        GLES30.glUniformMatrix4fv(uni.getValue("uVP"), 1, false, vp, 0)
        Matrix.setIdentityM(m, 0)
        Matrix.translateM(m, 0, cx, cy, 0f)
        Matrix.scaleM(m, 0, w, h, 1f)
        GLES30.glUniformMatrix4fv(uni.getValue("uModel"), 1, false, m, 0)
        GLES30.glUniform2f(uni.getValue("uSize"), w, h)
        GLES30.glUniform1f(uni.getValue("uRadius"), radius)
        GLES30.glUniform4f(uni.getValue("uSolid"), r, g, b, a)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    /** Model matrix of the small label that names a frame zone (for [mode]). */
    fun labelModel(p: Panel, mode: Int, out: FloatArray) {
        base(p, out)
        val w = p.width
        val h = w / p.aspect
        val ring = FRAME_M / 2f
        var x = 0f
        var y = 0f
        when (mode) {
            MODE_MOVE -> y = h / 2f + ring
            MODE_SIZE -> { x = -w / 2f + 0.2f; y = h / 2f + ring }
            MODE_ROLL -> { x = -w / 2f - 0.08f; y = h * 0.12f }
            MODE_DEPTH -> x = w / 2f + 0.08f
            MODE_ROTATE -> y = -h / 2f - ring
        }
        Matrix.translateM(out, 0, x, y, 0.02f)
        Matrix.scaleM(out, 0, 0.36f, 0.13f, 1f)
    }

    private fun compileProgram(vs: String, fs: String): Int {
        fun compile(type: Int, src: String): Int {
            val s = GLES30.glCreateShader(type)
            GLES30.glShaderSource(s, src)
            GLES30.glCompileShader(s)
            val ok = IntArray(1)
            GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Panel shader: " + GLES30.glGetShaderInfoLog(s))
            return s
        }
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, compile(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(prog, compile(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Panel link: " + GLES30.glGetProgramInfoLog(prog))
        return prog
    }
}
