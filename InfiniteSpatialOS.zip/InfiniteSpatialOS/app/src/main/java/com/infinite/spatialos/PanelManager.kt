package com.infinite.spatialos

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.Matrix
import android.view.Surface
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Owns every floating app panel: textures, placement, drawing, hit-testing and dragging. */
class PanelManager {

    companion object {
        const val MAX_PANELS = 3
        const val MODE_MOVE = 0
        const val MODE_SIZE = 1
        const val MODE_ROTATE = 2
        const val MODE_ROLL = 3
        const val MODE_DEPTH = 4
        private const val RING = 3.9f
        private const val BASE_Y = 0.3f
        private const val BAR_H = 0.17f
        private const val BAR_GAP = 0.05f
        private const val TAN_HALF_FOV = 0.4452f
    }

    class Panel(val id: Int, val w: Int, val h: Int) {
        @Volatile var displayId = -1
        var tex = 0
        var st: SurfaceTexture? = null
        var surface: Surface? = null
        @Volatile var frame = false
        @Volatile var hasFrame = false
        val stMatrix = FloatArray(16)
        @Volatile var x = 0f
        @Volatile var y = BASE_Y
        @Volatile var z = -RING
        @Volatile var yaw = 0f
        @Volatile var pitch = 0f
        @Volatile var roll = 0f
        @Volatile var width = 2.3f
        @Volatile var moved = false
        val aspect: Float get() = w.toFloat() / h.toFloat()
    }

    class Hit(val panel: Panel, val onBar: Boolean, val u: Float, val v: Float)

    val panels = CopyOnWriteArrayList<Panel>()
    @Volatile var selectedId = -1
    @Volatile var dragMode = MODE_MOVE
    private var nextId = 1

    private var program = 0
    private val uni = HashMap<String, Int>()
    private val m = FloatArray(16)

    fun init() {
        program = compileProgram(PanelShaders.VERTEX, PanelShaders.FRAGMENT)
        uni.clear()
        for (n in listOf("uVP", "uModel", "uTex", "uSTMatrix", "uSolid")) {
            uni[n] = GLES30.glGetUniformLocation(program, n)
        }
    }

    fun find(id: Int): Panel? = panels.firstOrNull { it.id == id }

    /** GL thread. */
    fun create(w: Int, h: Int): Panel {
        val p = Panel(nextId++, w, h)
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        p.tex = ids[0]
        val target = GLES11Ext.GL_TEXTURE_EXTERNAL_OES
        GLES30.glBindTexture(target, p.tex)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val st = SurfaceTexture(p.tex)
        st.setDefaultBufferSize(w, h)
        st.setOnFrameAvailableListener { p.frame = true }
        p.st = st
        p.surface = Surface(st)
        panels.add(p)
        selectedId = p.id
        relayout()
        return p
    }

    /** GL thread. */
    fun remove(id: Int) {
        val p = find(id) ?: return
        try {
            p.surface?.release()
            p.st?.release()
        } catch (_: Throwable) {
        }
        p.surface = null
        p.st = null
        p.hasFrame = false
        if (p.tex != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(p.tex), 0)
            p.tex = 0
        }
        panels.remove(p)
        if (selectedId == id) selectedId = panels.lastOrNull()?.id ?: -1
        relayout()
    }

    private fun relayout() {
        val list = panels.toList()
        val n = list.size
        if (n == 0) return
        val angles: FloatArray
        val width: Float
        when (n) {
            1 -> { angles = floatArrayOf(0f); width = 2.3f }
            2 -> { angles = floatArrayOf(-13.5f, 13.5f); width = 1.7f }
            else -> { angles = floatArrayOf(-23f, 0f, 23f); width = 1.55f }
        }
        for ((i, p) in list.withIndex()) {
            if (p.moved) continue
            val a = Math.toRadians(angles[i].toDouble())
            p.x = (RING * sin(a)).toFloat()
            p.z = (-RING * cos(a)).toFloat()
            p.yaw = -angles[i]
            p.pitch = 0f
            p.roll = 0f
            p.y = BASE_Y
            p.width = width
        }
    }

    private fun base(p: Panel, out: FloatArray) {
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, p.x, p.y, p.z)
        Matrix.rotateM(out, 0, p.yaw, 0f, 1f, 0f)
        Matrix.rotateM(out, 0, p.pitch, 1f, 0f, 0f)
        Matrix.rotateM(out, 0, p.roll, 0f, 0f, 1f)
    }

    private fun bodyModel(p: Panel, out: FloatArray) {
        base(p, out)
        Matrix.scaleM(out, 0, p.width, p.width / p.aspect, 1f)
    }

    private fun barModel(p: Panel, out: FloatArray) {
        base(p, out)
        val h = p.width / p.aspect
        Matrix.translateM(out, 0, 0f, h / 2f + BAR_GAP + BAR_H / 2f, 0f)
        Matrix.scaleM(out, 0, p.width, BAR_H, 1f)
    }

    /** GL thread. The unit quad VAO must already be bound. */
    fun draw(vp: FloatArray) {
        if (panels.isEmpty()) return
        GLES30.glUseProgram(program)
        GLES30.glUniformMatrix4fv(uni.getValue("uVP"), 1, false, vp, 0)
        GLES30.glUniform1i(uni.getValue("uTex"), 0)
        for (p in panels.sortedBy { it.z }) {
            val st = p.st ?: continue
            if (p.frame) {
                p.frame = false
                try {
                    st.updateTexImage()
                    st.getTransformMatrix(p.stMatrix)
                    p.hasFrame = true
                } catch (_: Throwable) {
                }
            }
            if (!p.hasFrame) continue

            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, p.tex)

            bodyModel(p, m)
            GLES30.glUniformMatrix4fv(uni.getValue("uModel"), 1, false, m, 0)
            GLES30.glUniformMatrix4fv(uni.getValue("uSTMatrix"), 1, false, p.stMatrix, 0)
            GLES30.glUniform4f(uni.getValue("uSolid"), 0f, 0f, 0f, 0f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

            val sel = p.id == selectedId
            barModel(p, m)
            GLES30.glUniformMatrix4fv(uni.getValue("uModel"), 1, false, m, 0)
            if (sel) GLES30.glUniform4f(uni.getValue("uSolid"), 0.22f, 0.5f, 0.96f, 0.95f)
            else GLES30.glUniform4f(uni.getValue("uSolid"), 0.55f, 0.6f, 0.68f, 0.85f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

            // grip pill in the middle of the bar
            barModel(p, m)
            Matrix.scaleM(m, 0, 0.14f / p.width * 1f, 0.28f, 1f)
            GLES30.glUniformMatrix4fv(uni.getValue("uModel"), 1, false, m, 0)
            GLES30.glUniform4f(uni.getValue("uSolid"), 1f, 1f, 1f, 0.85f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        }
    }

    private fun unproject(inv: FloatArray, nx: Float, ny: Float, nz: Float): FloatArray {
        val o = FloatArray(4)
        Matrix.multiplyMV(o, 0, inv, 0, floatArrayOf(nx, ny, nz, 1f), 0)
        return floatArrayOf(o[0] / o[3], o[1] / o[3], o[2] / o[3])
    }

    /** Intersects the screen point with the unit quad of [model]; returns local (x, y) or null. */
    private fun localHit(vp: FloatArray, model: FloatArray, sx: Float, sy: Float, vw: Int, vh: Int): FloatArray? {
        val mvp = FloatArray(16)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        val inv = FloatArray(16)
        if (!Matrix.invertM(inv, 0, mvp, 0)) return null
        val nx = sx / vw * 2f - 1f
        val ny = 1f - sy / vh * 2f
        val a = unproject(inv, nx, ny, -1f)
        val b = unproject(inv, nx, ny, 1f)
        val dz = b[2] - a[2]
        if (abs(dz) < 1e-6f) return null
        val t = -a[2] / dz
        return floatArrayOf(a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))
    }

    /** UI thread. Which panel (and which part) is under the finger, if any. */
    fun hitTest(vp: FloatArray, sx: Float, sy: Float, vw: Int, vh: Int): Hit? {
        val tmp = FloatArray(16)
        for (p in panels.sortedByDescending { it.z }) {
            if (!p.hasFrame) continue
            barModel(p, tmp)
            val bar = localHit(vp, tmp, sx, sy, vw, vh)
            if (bar != null && abs(bar[0]) <= 0.5f && abs(bar[1]) <= 0.5f) {
                return Hit(p, true, 0f, 0f)
            }
            bodyModel(p, tmp)
            val body = localHit(vp, tmp, sx, sy, vw, vh) ?: continue
            if (abs(body[0]) <= 0.5f && abs(body[1]) <= 0.5f) {
                return Hit(p, false, body[0] + 0.5f, 0.5f - body[1])
            }
        }
        return null
    }

    /** UI thread. Same as [hitTest] but for an already-grabbed panel; clamps to its edges. */
    fun uvOn(p: Panel, vp: FloatArray, sx: Float, sy: Float, vw: Int, vh: Int): FloatArray? {
        val tmp = FloatArray(16)
        bodyModel(p, tmp)
        val l = localHit(vp, tmp, sx, sy, vw, vh) ?: return null
        return floatArrayOf((l[0] + 0.5f).coerceIn(0f, 1f), (0.5f - l[1]).coerceIn(0f, 1f))
    }

    /** UI thread. Applies a drag of the title bar according to the current mode. */
    fun drag(p: Panel, dx: Float, dy: Float, vh: Int) {
        val upp = 2f * abs(p.z) * TAN_HALF_FOV / vh.coerceAtLeast(1)
        when (dragMode) {
            MODE_MOVE -> {
                p.x += dx * upp
                p.y -= dy * upp
            }
            MODE_SIZE -> p.width = (p.width - dy * upp * 1.5f).coerceIn(0.5f, 7f)
            MODE_ROTATE -> {
                p.yaw += dx * 0.25f
                p.pitch += dy * 0.25f
            }
            MODE_ROLL -> p.roll += dx * 0.25f
            MODE_DEPTH -> p.z = (p.z + dy * upp * 2f).coerceIn(-14f, -1.6f)
        }
        p.moved = true
    }

    private fun compileProgram(vs: String, fs: String): Int {
        fun compile(type: Int, src: String): Int {
            val s = GLES30.glCreateShader(type)
            GLES30.glShaderSource(s, src)
            GLES30.glCompileShader(s)
            val ok = IntArray(1)
            GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Panel shader: " + GLES30.glGetShaderInfoLog(s))
            return s
        }
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, compile(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(prog, compile(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(prog)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Panel link: " + GLES30.glGetProgramInfoLog(prog))
        return prog
    }
}
